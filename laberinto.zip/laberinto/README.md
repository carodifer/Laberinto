# Escape del Laberinto

Proyecto final de **Estructuras de Datos**. Juego de laberinto con interfaz
gráfica en el que el jugador debe llegar a la salida esquivando enemigos y
antes de que se acabe el tiempo.

**Integrantes:**
-Jose Angel Lopez Paz
-Carolina Diago Fernandez 

**Lenguaje:** Python 3.8 o superior
**Interfaz:** Tkinter (viene incluida con Python, no hay que instalar nada)

## Cómo ejecutarlo

```bash
python main.py
```

En Windows también funciona `py main.py`. En Linux, si aparece un error de
Tkinter, se instala con `sudo apt install python3-tk`.

## Cómo correr las pruebas

```bash
python -m unittest -v
```

## Controles

| Tecla | Acción |
|---|---|
| Flechas o W A S D | Moverse |
| Z o Retroceso | Deshacer el último movimiento |
| H | Pista (camino más corto a la salida) |
| P | Pausa |
| Esc | Volver al menú |

## Estructuras de datos (programadas desde cero, carpeta `estructuras/`)

| Estructura | Archivo | Uso en el juego |
|---|---|---|
| Pila | `pila.py` | Generar el laberinto con backtracking y deshacer movimientos |
| Cola | `cola.py` | BFS: pista del camino más corto y enemigo cazador |
| Lista circular | `lista_circular.py` | Ruta de patrulla de cada enemigo y conjunto de enemigos |
| Lista doble | `lista_doble.py` | Camino del jugador y repetición adelante/atrás; caminos del BFS; récords de mayor a menor |
| Árbol BST | `arbol_bst.py` | Tabla de mejores puntajes (buscar, eliminar, recorridos) |

No se usa ninguna colección de Python (`list` como pila, `deque`, `queue`,
etc.) para estas estructuras. La matriz del tablero es un arreglo 2D y no
es una de las estructuras evaluadas.

## Organización

```
main.py               punto de entrada
estructuras/          las 5 estructuras
juego/laberinto.py    generación (Pila) y BFS (Cola)
juego/enemigo.py      Patrullero (ListaCircular) y Cazador (BFS)
juego/partida.py      reglas, deshacer, tiempo, puntaje
juego/records.py      récords en ArbolBST y archivo records.txt
interfaz/app.py       pantallas de Tkinter
tests/                pruebas unitarias
```
