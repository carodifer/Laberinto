"""
Paquete con las cinco estructuras de datos programadas desde cero
(sin usar list, deque, ni ninguna colección de Python como estructura).
"""
from .pila import Pila
from .cola import Cola
from .lista_circular import ListaCircular
from .lista_doble import ListaDoble
from .arbol_bst import ArbolBST

__all__ = ["Pila", "Cola", "ListaCircular", "ListaDoble", "ArbolBST"]
