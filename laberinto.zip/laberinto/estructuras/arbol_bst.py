"""
Árbol binario de búsqueda (BST) implementado desde cero.

Uso en el juego:
  - Tabla de mejores puntajes. La clave es el puntaje; el valor es el
    récord completo (nombre, nivel, tiempo...). El recorrido inorden
    entrega los puntajes ordenados sin tener que ordenar nada.
  - Se admiten claves repetidas (dos jugadores con el mismo puntaje):
    las claves iguales se guardan en el subárbol derecho.
"""


class NodoArbol:
    """Nodo del árbol: clave, valor e hijos izquierdo y derecho."""

    def __init__(self, clave, valor):
        """Recibe: clave (comparable), valor (cualquier objeto). Devuelve: nada."""
        self.clave = clave
        self.valor = valor
        self.izquierdo = None
        self.derecho = None


class ArbolBST:
    """
    Árbol binario de búsqueda. h = altura del árbol
    (h = log n si está balanceado, h = n en el peor caso).

    Complejidad:
        insertar    O(h)
        buscar      O(h)
        eliminar    O(h)
        inorden     O(n)
        preorden    O(n)
        posorden    O(n)
        altura      O(n)
    """

    def __init__(self):
        """Crea un árbol vacío. Recibe: nada. Devuelve: nada."""
        self.raiz = None
        self._tamano = 0

    # ------------------------------------------------------------- insertar
    def insertar(self, clave, valor=None):
        """
        Inserta una clave con su valor. Claves iguales van a la derecha.
        Recibe: clave, valor. Devuelve: nada.
        """
        nuevo = NodoArbol(clave, valor)
        if self.raiz is None:
            self.raiz = nuevo
        else:
            actual = self.raiz
            while True:
                if clave < actual.clave:
                    if actual.izquierdo is None:
                        actual.izquierdo = nuevo
                        break
                    actual = actual.izquierdo
                else:
                    if actual.derecho is None:
                        actual.derecho = nuevo
                        break
                    actual = actual.derecho
        self._tamano += 1

    # --------------------------------------------------------------- buscar
    def buscar(self, clave):
        """
        Busca la primera aparición de una clave.
        Recibe: clave. Devuelve: el valor asociado o None si no existe.
        """
        actual = self.raiz
        while actual is not None:
            if clave == actual.clave:
                return actual.valor
            actual = actual.izquierdo if clave < actual.clave else actual.derecho
        return None

    def contiene(self, clave):
        """Recibe: clave. Devuelve: True si la clave está en el árbol."""
        actual = self.raiz
        while actual is not None:
            if clave == actual.clave:
                return True
            actual = actual.izquierdo if clave < actual.clave else actual.derecho
        return False

    # ------------------------------------------------------------- eliminar
    def eliminar(self, clave, valor=None):
        """
        Elimina un nodo con esa clave. Si se da 'valor', elimina el nodo
        cuya clave Y valor coinciden (útil con claves repetidas).
        Recibe: clave, valor (opcional). Devuelve: True si eliminó algo.
        """
        self._eliminado = False
        self.raiz = self._eliminar(self.raiz, clave, valor)
        if self._eliminado:
            self._tamano -= 1
        return self._eliminado

    def _eliminar(self, nodo, clave, valor):
        """
        Eliminación recursiva (uso interno).
        Recibe: nodo (subárbol), clave, valor. Devuelve: nueva raíz del subárbol.
        Casos: hoja, un solo hijo, dos hijos (se reemplaza por el sucesor
        inorden = el menor del subárbol derecho).
        """
        if nodo is None:
            return None
        if clave < nodo.clave:
            nodo.izquierdo = self._eliminar(nodo.izquierdo, clave, valor)
            return nodo
        if clave > nodo.clave or (valor is not None and nodo.valor != valor):
            # clave mayor, o clave igual pero no es el valor buscado:
            # las claves repetidas están a la derecha
            nodo.derecho = self._eliminar(nodo.derecho, clave, valor)
            return nodo
        # este es el nodo a eliminar
        self._eliminado = True
        if nodo.izquierdo is None:
            return nodo.derecho
        if nodo.derecho is None:
            return nodo.izquierdo
        sucesor = nodo.derecho
        while sucesor.izquierdo is not None:
            sucesor = sucesor.izquierdo
        nodo.clave, nodo.valor = sucesor.clave, sucesor.valor
        nodo.derecho = self._quitar_minimo(nodo.derecho)
        return nodo

    def _quitar_minimo(self, nodo):
        """
        Quita el nodo más a la izquierda de un subárbol (uso interno).
        Recibe: nodo. Devuelve: nueva raíz del subárbol.
        """
        if nodo.izquierdo is None:
            return nodo.derecho
        nodo.izquierdo = self._quitar_minimo(nodo.izquierdo)
        return nodo

    # ----------------------------------------------------------- recorridos
    def inorden(self, visitar):
        """
        Izquierdo - raíz - derecho: visita las claves de menor a mayor.
        Recibe: visitar (función que recibe clave y valor). Devuelve: nada.
        """
        self._inorden(self.raiz, visitar)

    def _inorden(self, nodo, visitar):
        if nodo is not None:
            self._inorden(nodo.izquierdo, visitar)
            visitar(nodo.clave, nodo.valor)
            self._inorden(nodo.derecho, visitar)

    def preorden(self, visitar):
        """
        Raíz - izquierdo - derecho.
        Recibe: visitar (función que recibe clave y valor). Devuelve: nada.
        """
        self._preorden(self.raiz, visitar)

    def _preorden(self, nodo, visitar):
        if nodo is not None:
            visitar(nodo.clave, nodo.valor)
            self._preorden(nodo.izquierdo, visitar)
            self._preorden(nodo.derecho, visitar)

    def posorden(self, visitar):
        """
        Izquierdo - derecho - raíz.
        Recibe: visitar (función que recibe clave y valor). Devuelve: nada.
        """
        self._posorden(self.raiz, visitar)

    def _posorden(self, nodo, visitar):
        if nodo is not None:
            self._posorden(nodo.izquierdo, visitar)
            self._posorden(nodo.derecho, visitar)
            visitar(nodo.clave, nodo.valor)

    # -------------------------------------------------------------- otros
    def altura(self):
        """Recibe: nada. Devuelve: altura del árbol (0 si está vacío)."""
        return self._altura(self.raiz)

    def _altura(self, nodo):
        if nodo is None:
            return 0
        return 1 + max(self._altura(nodo.izquierdo), self._altura(nodo.derecho))

    def esta_vacio(self):
        """Recibe: nada. Devuelve: True si no hay nodos."""
        return self.raiz is None

    def tamano(self):
        """Recibe: nada. Devuelve: número de nodos (int)."""
        return self._tamano

    def __len__(self):
        """Permite usar len(arbol). Devuelve: tamaño."""
        return self._tamano
