"""
Cola (FIFO) implementada desde cero con nodos enlazados.

Uso en el juego:
  - Búsqueda en anchura (BFS) para hallar el camino más corto
    (botón "Pista" y el enemigo cazador del nivel Difícil).
"""


class NodoCola:
    """Nodo de la cola: guarda un dato y la referencia al siguiente."""

    def __init__(self, dato):
        """
        Crea un nodo.
        Recibe: dato. Devuelve: nada.
        """
        self.dato = dato
        self.siguiente = None


class Cola:
    """
    Cola enlazada con referencia al frente y al final.

    Complejidad:
        encolar     O(1)
        desencolar  O(1)
        ver_frente  O(1)
        esta_vacia  O(1)
        tamano      O(1)
    """

    def __init__(self):
        """Crea una cola vacía. Recibe: nada. Devuelve: nada."""
        self._frente = None
        self._final = None
        self._tamano = 0

    def encolar(self, dato):
        """
        Agrega un elemento al final.
        Recibe: dato. Devuelve: nada.
        """
        nuevo = NodoCola(dato)
        if self._final is None:
            self._frente = nuevo
        else:
            self._final.siguiente = nuevo
        self._final = nuevo
        self._tamano += 1

    def desencolar(self):
        """
        Quita y devuelve el elemento del frente.
        Recibe: nada. Devuelve: el dato del frente.
        Lanza IndexError si la cola está vacía.
        """
        if self.esta_vacia():
            raise IndexError("desencolar de una cola vacía")
        dato = self._frente.dato
        self._frente = self._frente.siguiente
        if self._frente is None:
            self._final = None
        self._tamano -= 1
        return dato

    def ver_frente(self):
        """
        Devuelve el dato del frente sin quitarlo.
        Recibe: nada. Devuelve: el dato del frente.
        Lanza IndexError si la cola está vacía.
        """
        if self.esta_vacia():
            raise IndexError("ver_frente de una cola vacía")
        return self._frente.dato

    def esta_vacia(self):
        """Recibe: nada. Devuelve: True si no hay elementos."""
        return self._frente is None

    def tamano(self):
        """Recibe: nada. Devuelve: número de elementos (int)."""
        return self._tamano

    def __len__(self):
        """Permite usar len(cola). Devuelve: tamaño."""
        return self._tamano
