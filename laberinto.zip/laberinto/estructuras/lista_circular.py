"""
Lista circular simplemente enlazada implementada desde cero.

El último nodo apunta de nuevo al primero, así que se puede recorrer
"para siempre". Además tiene un cursor que avanza un nodo a la vez.

Uso en el juego:
  - Ruta de patrulla de cada enemigo: el enemigo avanza por la ruta
    y al llegar al final vuelve a empezar sin hacer nada especial.
  - El conjunto de enemigos de la partida.
"""


class NodoCircular:
    """Nodo de la lista circular: dato y referencia al siguiente."""

    def __init__(self, dato):
        """Recibe: dato. Devuelve: nada."""
        self.dato = dato
        self.siguiente = None


class ListaCircular:
    """
    Lista circular. Se guarda la referencia al ÚLTIMO nodo; el primero
    es ultimo.siguiente. Así insertar al inicio y al final es O(1).

    Complejidad:
        insertar_inicio        O(1)
        insertar_final         O(1)
        insertar_en_posicion   O(n)
        eliminar (por dato)    O(n)
        eliminar_en_posicion   O(n)
        buscar                 O(n)
        obtener                O(n)
        recorrer               O(n)
        avanzar (cursor)       O(1)
    """

    def __init__(self):
        """Crea una lista vacía. Recibe: nada. Devuelve: nada."""
        self._ultimo = None
        self._tamano = 0
        self._cursor = None  # nodo actual para avanzar()

    # ------------------------------------------------------------ inserción
    def insertar_inicio(self, dato):
        """
        Inserta un dato al inicio.
        Recibe: dato. Devuelve: nada.
        """
        nuevo = NodoCircular(dato)
        if self._ultimo is None:
            nuevo.siguiente = nuevo
            self._ultimo = nuevo
        else:
            nuevo.siguiente = self._ultimo.siguiente
            self._ultimo.siguiente = nuevo
        self._tamano += 1

    def insertar_final(self, dato):
        """
        Inserta un dato al final.
        Recibe: dato. Devuelve: nada.
        """
        self.insertar_inicio(dato)
        # el nuevo quedó de primero; basta con mover "ultimo" un paso
        self._ultimo = self._ultimo.siguiente

    def insertar_en_posicion(self, dato, posicion):
        """
        Inserta un dato en la posición indicada (0 = inicio, tamaño = final).
        Recibe: dato, posicion (int). Devuelve: nada.
        Lanza IndexError si la posición está fuera de rango.
        """
        if posicion < 0 or posicion > self._tamano:
            raise IndexError("posición fuera de rango")
        if posicion == 0:
            self.insertar_inicio(dato)
            return
        if posicion == self._tamano:
            self.insertar_final(dato)
            return
        anterior = self._ultimo.siguiente
        for _ in range(posicion - 1):
            anterior = anterior.siguiente
        nuevo = NodoCircular(dato)
        nuevo.siguiente = anterior.siguiente
        anterior.siguiente = nuevo
        self._tamano += 1

    # ----------------------------------------------------------- eliminación
    def _quitar_despues_de(self, anterior):
        """
        Quita el nodo que sigue a 'anterior' (uso interno).
        Recibe: anterior (NodoCircular). Devuelve: el dato quitado.
        """
        victima = anterior.siguiente
        if victima is anterior:          # era el único nodo
            self._ultimo = None
            self._cursor = None
        else:
            anterior.siguiente = victima.siguiente
            if victima is self._ultimo:
                self._ultimo = anterior
            if self._cursor is victima:
                self._cursor = victima.siguiente
        self._tamano -= 1
        return victima.dato

    def eliminar(self, dato):
        """
        Elimina la primera aparición de un dato.
        Recibe: dato. Devuelve: True si lo eliminó, False si no estaba.
        """
        if self._ultimo is None:
            return False
        anterior = self._ultimo
        for _ in range(self._tamano):
            if anterior.siguiente.dato == dato:
                self._quitar_despues_de(anterior)
                return True
            anterior = anterior.siguiente
        return False

    def eliminar_en_posicion(self, posicion):
        """
        Elimina el elemento de una posición.
        Recibe: posicion (int). Devuelve: el dato eliminado.
        Lanza IndexError si la posición está fuera de rango.
        """
        if posicion < 0 or posicion >= self._tamano:
            raise IndexError("posición fuera de rango")
        anterior = self._ultimo
        for _ in range(posicion):
            anterior = anterior.siguiente
        return self._quitar_despues_de(anterior)

    # -------------------------------------------------------------- consulta
    def buscar(self, dato):
        """
        Busca un dato.
        Recibe: dato. Devuelve: su posición (int) o -1 si no está.
        """
        if self._ultimo is None:
            return -1
        actual = self._ultimo.siguiente
        for i in range(self._tamano):
            if actual.dato == dato:
                return i
            actual = actual.siguiente
        return -1

    def obtener(self, posicion):
        """
        Recibe: posicion (int). Devuelve: el dato en esa posición.
        Lanza IndexError si la posición está fuera de rango.
        """
        if posicion < 0 or posicion >= self._tamano:
            raise IndexError("posición fuera de rango")
        actual = self._ultimo.siguiente
        for _ in range(posicion):
            actual = actual.siguiente
        return actual.dato

    def recorrer(self, visitar):
        """
        Recorre la lista una vuelta completa desde el inicio.
        Recibe: visitar (función que recibe cada dato). Devuelve: nada.
        """
        if self._ultimo is None:
            return
        actual = self._ultimo.siguiente
        for _ in range(self._tamano):
            visitar(actual.dato)
            actual = actual.siguiente

    def __iter__(self):
        """Permite usar 'for dato in lista' (una vuelta). Devuelve: generador."""
        if self._ultimo is None:
            return
        actual = self._ultimo.siguiente
        for _ in range(self._tamano):
            yield actual.dato
            actual = actual.siguiente

    # ---------------------------------------------------------------- cursor
    def avanzar(self):
        """
        Mueve el cursor al siguiente nodo (dando vueltas) y devuelve su dato.
        La primera llamada devuelve el primer elemento.
        Recibe: nada. Devuelve: dato del nodo actual.
        Lanza IndexError si la lista está vacía.
        """
        if self._ultimo is None:
            raise IndexError("avanzar en una lista vacía")
        if self._cursor is None:
            self._cursor = self._ultimo.siguiente
        else:
            self._cursor = self._cursor.siguiente
        return self._cursor.dato

    def actual(self):
        """Recibe: nada. Devuelve: dato bajo el cursor (o None si no ha avanzado)."""
        return None if self._cursor is None else self._cursor.dato

    def esta_vacia(self):
        """Recibe: nada. Devuelve: True si no hay elementos."""
        return self._ultimo is None

    def tamano(self):
        """Recibe: nada. Devuelve: número de elementos (int)."""
        return self._tamano

    def __len__(self):
        """Permite usar len(lista). Devuelve: tamaño."""
        return self._tamano
