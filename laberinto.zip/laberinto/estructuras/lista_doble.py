"""
Lista doblemente enlazada implementada desde cero.

Cada nodo conoce al anterior y al siguiente, así que se puede recorrer
en ambos sentidos.

Uso en el juego:
  - Camino recorrido por el jugador. Al terminar la partida se ve la
    repetición paso a paso hacia adelante y hacia atrás.
  - Camino que devuelve el BFS (pista).
  - Mostrar los récords de mayor a menor (recorrido hacia atrás).
"""


class NodoDoble:
    """Nodo con dato, referencia al anterior y al siguiente."""

    def __init__(self, dato):
        """Recibe: dato. Devuelve: nada."""
        self.dato = dato
        self.anterior = None
        self.siguiente = None


class ListaDoble:
    """
    Lista doble con referencias a la cabeza (primer nodo) y a la cola
    (último nodo).

    Complejidad:
        insertar_inicio        O(1)
        insertar_final         O(1)
        insertar_en_posicion   O(n)
        eliminar (por dato)    O(n)
        eliminar_inicio        O(1)
        eliminar_final         O(1)
        eliminar_en_posicion   O(n)
        buscar                 O(n)
        obtener                O(n)
        recorrer_adelante      O(n)
        recorrer_atras         O(n)
    """

    def __init__(self):
        """Crea una lista vacía. Recibe: nada. Devuelve: nada."""
        self.cabeza = None
        self.cola = None
        self._tamano = 0

    # ------------------------------------------------------------ inserción
    def insertar_inicio(self, dato):
        """Inserta al inicio. Recibe: dato. Devuelve: nada."""
        nuevo = NodoDoble(dato)
        if self.cabeza is None:
            self.cabeza = self.cola = nuevo
        else:
            nuevo.siguiente = self.cabeza
            self.cabeza.anterior = nuevo
            self.cabeza = nuevo
        self._tamano += 1

    def insertar_final(self, dato):
        """Inserta al final. Recibe: dato. Devuelve: nada."""
        nuevo = NodoDoble(dato)
        if self.cola is None:
            self.cabeza = self.cola = nuevo
        else:
            nuevo.anterior = self.cola
            self.cola.siguiente = nuevo
            self.cola = nuevo
        self._tamano += 1

    def insertar_en_posicion(self, dato, posicion):
        """
        Inserta en una posición (0 = inicio, tamaño = final).
        Recibe: dato, posicion (int). Devuelve: nada.
        Lanza IndexError si la posición está fuera de rango.
        """
        if posicion < 0 or posicion > self._tamano:
            raise IndexError("posición fuera de rango")
        if posicion == 0:
            self.insertar_inicio(dato)
        elif posicion == self._tamano:
            self.insertar_final(dato)
        else:
            siguiente = self._nodo_en(posicion)
            nuevo = NodoDoble(dato)
            nuevo.anterior = siguiente.anterior
            nuevo.siguiente = siguiente
            siguiente.anterior.siguiente = nuevo
            siguiente.anterior = nuevo
            self._tamano += 1

    # ----------------------------------------------------------- eliminación
    def _desenlazar(self, nodo):
        """
        Saca un nodo de la lista (uso interno).
        Recibe: nodo (NodoDoble). Devuelve: su dato.
        """
        if nodo.anterior is None:
            self.cabeza = nodo.siguiente
        else:
            nodo.anterior.siguiente = nodo.siguiente
        if nodo.siguiente is None:
            self.cola = nodo.anterior
        else:
            nodo.siguiente.anterior = nodo.anterior
        nodo.anterior = nodo.siguiente = None
        self._tamano -= 1
        return nodo.dato

    def eliminar(self, dato):
        """
        Elimina la primera aparición de un dato.
        Recibe: dato. Devuelve: True si lo eliminó, False si no estaba.
        """
        actual = self.cabeza
        while actual is not None:
            if actual.dato == dato:
                self._desenlazar(actual)
                return True
            actual = actual.siguiente
        return False

    def eliminar_inicio(self):
        """Quita el primero. Devuelve: su dato. IndexError si está vacía."""
        if self.cabeza is None:
            raise IndexError("lista vacía")
        return self._desenlazar(self.cabeza)

    def eliminar_final(self):
        """Quita el último. Devuelve: su dato. IndexError si está vacía."""
        if self.cola is None:
            raise IndexError("lista vacía")
        return self._desenlazar(self.cola)

    def eliminar_en_posicion(self, posicion):
        """
        Recibe: posicion (int). Devuelve: el dato eliminado.
        Lanza IndexError si la posición está fuera de rango.
        """
        return self._desenlazar(self._nodo_en(posicion))

    # -------------------------------------------------------------- consulta
    def _nodo_en(self, posicion):
        """
        Devuelve el nodo de una posición, empezando por el extremo más
        cercano (por eso es más rápido que en una lista simple).
        Recibe: posicion (int). Devuelve: NodoDoble.
        """
        if posicion < 0 or posicion >= self._tamano:
            raise IndexError("posición fuera de rango")
        if posicion < self._tamano // 2:
            actual = self.cabeza
            for _ in range(posicion):
                actual = actual.siguiente
        else:
            actual = self.cola
            for _ in range(self._tamano - 1 - posicion):
                actual = actual.anterior
        return actual

    def obtener(self, posicion):
        """Recibe: posicion (int). Devuelve: el dato en esa posición."""
        return self._nodo_en(posicion).dato

    def buscar(self, dato):
        """
        Recibe: dato. Devuelve: posición (int) o -1 si no está.
        """
        actual = self.cabeza
        i = 0
        while actual is not None:
            if actual.dato == dato:
                return i
            actual = actual.siguiente
            i += 1
        return -1

    def recorrer_adelante(self, visitar):
        """
        Recorre de la cabeza a la cola.
        Recibe: visitar (función que recibe cada dato). Devuelve: nada.
        """
        actual = self.cabeza
        while actual is not None:
            visitar(actual.dato)
            actual = actual.siguiente

    def recorrer_atras(self, visitar):
        """
        Recorre de la cola a la cabeza.
        Recibe: visitar (función que recibe cada dato). Devuelve: nada.
        """
        actual = self.cola
        while actual is not None:
            visitar(actual.dato)
            actual = actual.anterior

    def __iter__(self):
        """Permite 'for dato in lista' (hacia adelante). Devuelve: generador."""
        actual = self.cabeza
        while actual is not None:
            yield actual.dato
            actual = actual.siguiente

    def esta_vacia(self):
        """Recibe: nada. Devuelve: True si no hay elementos."""
        return self.cabeza is None

    def tamano(self):
        """Recibe: nada. Devuelve: número de elementos (int)."""
        return self._tamano

    def __len__(self):
        """Permite usar len(lista). Devuelve: tamaño."""
        return self._tamano
