"""
Pila (LIFO) implementada desde cero con nodos enlazados.

Uso en el juego:
  - Generar el laberinto con backtracking (DFS iterativo).
  - Deshacer movimientos del jugador.
"""


class NodoPila:
    """Nodo de la pila: guarda un dato y la referencia al nodo de abajo."""

    def __init__(self, dato, siguiente=None):
        """
        Crea un nodo.
        Recibe: dato (cualquier objeto), siguiente (NodoPila o None).
        Devuelve: nada.
        """
        self.dato = dato
        self.siguiente = siguiente


class Pila:
    """
    Pila enlazada. El tope es el primer nodo de la cadena.

    Complejidad:
        apilar      O(1)
        desapilar   O(1)
        ver_tope    O(1)
        esta_vacia  O(1)
        tamano      O(1)  (se lleva un contador)
        vaciar      O(1)
    """

    def __init__(self):
        """Crea una pila vacía. Recibe: nada. Devuelve: nada."""
        self._tope = None
        self._tamano = 0

    def apilar(self, dato):
        """
        Pone un elemento en el tope.
        Recibe: dato. Devuelve: nada.
        """
        self._tope = NodoPila(dato, self._tope)
        self._tamano += 1

    def desapilar(self):
        """
        Quita y devuelve el elemento del tope.
        Recibe: nada. Devuelve: el dato del tope.
        Lanza IndexError si la pila está vacía.
        """
        if self.esta_vacia():
            raise IndexError("desapilar de una pila vacía")
        dato = self._tope.dato
        self._tope = self._tope.siguiente
        self._tamano -= 1
        return dato

    def ver_tope(self):
        """
        Devuelve el dato del tope sin quitarlo.
        Recibe: nada. Devuelve: el dato del tope.
        Lanza IndexError si la pila está vacía.
        """
        if self.esta_vacia():
            raise IndexError("ver_tope de una pila vacía")
        return self._tope.dato

    def esta_vacia(self):
        """Recibe: nada. Devuelve: True si no hay elementos."""
        return self._tope is None

    def tamano(self):
        """Recibe: nada. Devuelve: número de elementos (int)."""
        return self._tamano

    def vaciar(self):
        """Elimina todos los elementos. Recibe: nada. Devuelve: nada."""
        self._tope = None
        self._tamano = 0

    def __len__(self):
        """Permite usar len(pila). Devuelve: tamaño."""
        return self._tamano
