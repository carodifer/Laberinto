"""
Interfaz gráfica del juego con Tkinter (viene incluida con Python).

La interfaz SOLO dibuja y recibe teclas/clics. Toda la lógica está en
el paquete 'juego' y todas las estructuras en el paquete 'estructuras'.

Pantallas:
  MenuPrincipal -> PantallaJuego -> PantallaResultado -> PantallaRepeticion
  MenuPrincipal -> PantallaRecords
  MenuPrincipal -> PantallaReglas
"""
import tkinter as tk
from tkinter import messagebox

from juego.partida import Partida, NIVELES, JUGANDO, GANADO, PENALIZACION_PISTA, PENALIZACION_DESHACER
from juego.laberinto import PARED
from estructuras import ListaDoble
from juego.records import GestorRecords, Record, validar_nombre, validar_entero

# ------------------------------------------------------------------ colores
FONDO = "#14182b"
PANEL = "#1e2440"
TEXTO = "#e8ebf7"
TEXTO_SUAVE = "#9aa3c7"
ACENTO = "#4cc9f0"
COLOR_PARED = "#2b3360"
COLOR_PISO = "#f1f3fb"
COLOR_RASTRO = "#b9e6f7"
COLOR_PISTA = "#ffd166"
COLOR_JUGADOR = "#3a86ff"
COLOR_SALIDA = "#06d6a0"
COLOR_PATRULLERO = "#ef476f"
COLOR_CAZADOR = "#9b5de5"
COLOR_BOTON = "#3a86ff"
COLOR_BOTON_HOVER = "#5fa0ff"
COLOR_PELIGRO = "#ef476f"

FUENTE = "Segoe UI"
ANCHO_LIENZO = 780
ALTO_LIENZO = 600

# teclas de movimiento -> (cambio de fila, cambio de columna)
TECLAS_MOVIMIENTO = {
    "Up": (-1, 0), "w": (-1, 0), "W": (-1, 0),
    "Down": (1, 0), "s": (1, 0), "S": (1, 0),
    "Left": (0, -1), "a": (0, -1), "A": (0, -1),
    "Right": (0, 1), "d": (0, 1), "D": (0, 1),
}


def boton(padre, texto, comando, color=COLOR_BOTON, ancho=18):
    """
    Crea un botón con estilo propio (un Label que responde al clic), para
    que se vea igual en Windows, Mac y Linux.
    Recibe: padre (widget), texto (str), comando (función sin parámetros),
            color (str), ancho (int). Devuelve: el widget creado.
    """
    hover = COLOR_BOTON_HOVER if color == COLOR_BOTON else color
    b = tk.Label(padre, text=texto, bg=color, fg="white", font=(FUENTE, 12, "bold"),
                 width=ancho, pady=7, cursor="hand2")
    b.bind("<Button-1>", lambda e: comando())
    b.bind("<Enter>", lambda e: b.config(bg=hover, relief="raised"))
    b.bind("<Leave>", lambda e: b.config(bg=color, relief="flat"))
    return b


def titulo(padre, texto, tamano=26):
    """Crea un título. Recibe: padre, texto, tamano. Devuelve: Label."""
    return tk.Label(padre, text=texto, bg=FONDO, fg=TEXTO, font=(FUENTE, tamano, "bold"))


class App(tk.Tk):
    """Ventana principal: cambia entre pantallas."""

    def __init__(self, ruta_records):
        """
        Recibe: ruta_records (str, archivo donde se guardan los récords).
        Devuelve: nada.
        """
        super().__init__()
        self.title("Escape del Laberinto — Estructuras de Datos")
        self.configure(bg=FONDO)
        self.geometry("1080x700")
        self.minsize(1000, 680)
        self.records = GestorRecords(ruta_records)
        self.nivel = tk.StringVar(value="Fácil")
        self.pantalla = None
        self.protocol("WM_DELETE_WINDOW", self.salir)
        self.mostrar(MenuPrincipal)

    def mostrar(self, clase, **datos):
        """
        Destruye la pantalla actual y muestra otra.
        Recibe: clase (clase de la pantalla), datos (parámetros extra).
        Devuelve: nada.
        """
        if self.pantalla is not None:
            self.pantalla.cerrar()
            self.pantalla.destroy()
        self.unbind("<KeyPress>")
        self.pantalla = clase(self, **datos)
        self.pantalla.pack(fill="both", expand=True)
        self.pantalla.focus_set()

    def report_callback_exception(self, tipo, valor, traza):
        """
        Si ocurre un error inesperado, se muestra un mensaje en vez de
        cerrar el juego. Recibe: datos del error. Devuelve: nada.
        """
        messagebox.showerror("Error", "Ocurrió un error inesperado:\n%s" % valor)

    def salir(self):
        """Pregunta antes de cerrar la ventana. Recibe: nada. Devuelve: nada."""
        if messagebox.askyesno("Salir", "¿Seguro que quieres salir del juego?"):
            self.destroy()


class Pantalla(tk.Frame):
    """Base de todas las pantallas."""

    def __init__(self, app):
        """Recibe: app (App). Devuelve: nada."""
        super().__init__(app, bg=FONDO)
        self.app = app

    def cerrar(self):
        """Se llama antes de destruir la pantalla (cancelar temporizadores)."""


# ======================================================================= MENÚ
class MenuPrincipal(Pantalla):
    """Menú principal: elegir nivel, jugar, ver récords, reglas o salir."""

    def __init__(self, app):
        """Recibe: app. Devuelve: nada."""
        super().__init__(app)
        caja = tk.Frame(self, bg=FONDO)
        caja.place(relx=0.5, rely=0.5, anchor="center")
        titulo(caja, "ESCAPE DEL LABERINTO", 34).pack(pady=(0, 4))
        tk.Label(caja, text="Proyecto final · Estructuras de Datos", bg=FONDO,
                 fg=TEXTO_SUAVE, font=(FUENTE, 13)).pack(pady=(0, 26))

        niveles = tk.Frame(caja, bg=PANEL, padx=18, pady=12)
        niveles.pack(pady=(0, 22))
        tk.Label(niveles, text="Nivel", bg=PANEL, fg=TEXTO, font=(FUENTE, 12, "bold")).pack()
        fila = tk.Frame(niveles, bg=PANEL)
        fila.pack()
        for nombre in NIVELES:
            tk.Radiobutton(fila, text=nombre, value=nombre, variable=app.nivel,
                           bg=PANEL, fg=TEXTO, selectcolor=FONDO, activebackground=PANEL,
                           activeforeground=ACENTO, font=(FUENTE, 12)).pack(side="left", padx=10)

        boton(caja, "▶  Jugar", self.jugar).pack(pady=5)
        boton(caja, "🏆  Mejores puntajes", lambda: app.mostrar(PantallaRecords)).pack(pady=5)
        boton(caja, "📖  Cómo jugar", lambda: app.mostrar(PantallaReglas)).pack(pady=5)
        boton(caja, "✖  Salir", app.salir, color=COLOR_PELIGRO).pack(pady=5)
        tk.Label(caja, text="Tecla Enter = jugar", bg=FONDO, fg=TEXTO_SUAVE,
                 font=(FUENTE, 10)).pack(pady=(16, 0))
        app.bind("<KeyPress>", self._tecla)

    def _tecla(self, evento):
        """Enter inicia el juego. Recibe: evento. Devuelve: nada."""
        if evento.keysym == "Return":
            self.jugar()

    def jugar(self):
        """Empieza una partida en el nivel elegido. Recibe/Devuelve: nada."""
        nivel = self.app.nivel.get()
        if nivel not in NIVELES:
            messagebox.showwarning("Nivel", "Elige un nivel válido.")
            return
        self.app.mostrar(PantallaJuego, nivel=nivel)


# ===================================================================== REGLAS
class PantallaReglas(Pantalla):
    """Explica las reglas y los controles."""

    TEXTO_REGLAS = (
        "OBJETIVO\n"
        "  Lleva tu ficha azul desde la entrada (arriba a la izquierda)\n"
        "  hasta la salida verde (abajo a la derecha).\n\n"
        "CÓMO SE GANA\n"
        "  Llegando a la salida antes de que se acabe el tiempo.\n\n"
        "CÓMO SE PIERDE\n"
        "  • Si un enemigo te alcanza (rojo = patrullero, morado = cazador).\n"
        "  • Si el tiempo llega a cero.\n"
        "  • Si te rindes.\n\n"
        "CONTROLES\n"
        "  Flechas o W A S D ..... moverse\n"
        "  Z o Retroceso ......... deshacer el último movimiento (-5 pts)\n"
        "  H ..................... pista: muestra el camino más corto (-50 pts)\n"
        "  P ..................... pausa\n"
        "  Esc ................... volver al menú\n\n"
        "NIVELES\n"
        "  Fácil: laberinto pequeño, 2 patrulleros, 120 s, puntaje x1\n"
        "  Medio: laberinto mediano, 4 patrulleros, 150 s, puntaje x2\n"
        "  Difícil: laberinto grande, 5 patrulleros + 1 cazador que te\n"
        "           persigue, 180 s, puntaje x3\n\n"
        "PUNTAJE (solo si ganas)\n"
        "  (500 + 10 × segundos sobrantes − movimientos − 50 × pistas\n"
        "   − 5 × deshacer) × multiplicador del nivel"
    )

    def __init__(self, app):
        """Recibe: app. Devuelve: nada."""
        super().__init__(app)
        titulo(self, "Cómo jugar").pack(pady=(24, 10))
        tk.Label(self, text=self.TEXTO_REGLAS, bg=PANEL, fg=TEXTO, justify="left",
                 font=("Consolas", 12), padx=24, pady=18).pack()
        boton(self, "← Volver al menú", lambda: app.mostrar(MenuPrincipal)).pack(pady=18)
        app.bind("<KeyPress>", lambda e: app.mostrar(MenuPrincipal) if e.keysym == "Escape" else None)


# ===================================================================== JUEGO
class PantallaJuego(Pantalla):
    """Dibuja el laberinto y controla el juego en tiempo real."""

    def __init__(self, app, nivel):
        """Recibe: app, nivel (str). Devuelve: nada."""
        super().__init__(app)
        self.partida = Partida(nivel)
        self.pausado = False
        self.camino_pista = None
        self._id_enemigos = None
        self._id_reloj = None
        self._id_pista = None
        self._terminado = False

        lab = self.partida.laberinto
        self.celda = max(8, min(ANCHO_LIENZO // lab.columnas, ALTO_LIENZO // lab.filas))
        ancho, alto = self.celda * lab.columnas, self.celda * lab.filas

        contenedor = tk.Frame(self, bg=FONDO)
        contenedor.pack(expand=True)
        self.lienzo = tk.Canvas(contenedor, width=ancho, height=alto, bg=COLOR_PISO,
                                highlightthickness=0)
        self.lienzo.grid(row=0, column=0, padx=(16, 12), pady=16)
        self._crear_panel(contenedor)
        self._dibujar_tablero()
        self._dibujar_dinamico()

        app.bind("<KeyPress>", self._tecla)
        self._id_reloj = self.after(1000, self._reloj)
        self._id_enemigos = self.after(self.partida.config["velocidad_ms"], self._turno_enemigos)

    # ------------------------------------------------------------ panel
    def _crear_panel(self, padre):
        """Crea el panel lateral con datos y botones. Recibe: padre. Devuelve: nada."""
        panel = tk.Frame(padre, bg=PANEL, padx=16, pady=16)
        panel.grid(row=0, column=1, sticky="n", pady=16, padx=(0, 16))
        tk.Label(panel, text="Nivel " + self.partida.nivel, bg=PANEL, fg=ACENTO,
                 font=(FUENTE, 16, "bold")).pack(anchor="w", pady=(0, 10))
        self.lbl_tiempo = self._dato(panel, "Tiempo")
        self.lbl_movs = self._dato(panel, "Movimientos")
        self.lbl_deshacer = self._dato(panel, "Deshacer usados")
        self.lbl_pistas = self._dato(panel, "Pistas usadas")
        self.lbl_estado = tk.Label(panel, text="", bg=PANEL, fg=COLOR_PISTA,
                                   font=(FUENTE, 11, "bold"), wraplength=190, justify="left")
        self.lbl_estado.pack(anchor="w", pady=(6, 10))
        boton(panel, "↶ Deshacer (Z)", self.deshacer, ancho=16).pack(pady=3)
        boton(panel, "💡 Pista (H)", self.mostrar_pista, ancho=16).pack(pady=3)
        boton(panel, "⏸ Pausa (P)", self.pausar, ancho=16).pack(pady=3)
        boton(panel, "🏳 Rendirse", self.rendirse, color=COLOR_PELIGRO, ancho=16).pack(pady=3)
        boton(panel, "← Menú (Esc)", self.volver_menu, color="#555d85", ancho=16).pack(pady=3)

        leyenda = tk.Frame(panel, bg=PANEL)
        leyenda.pack(anchor="w", pady=(14, 0))
        for color, texto in ((COLOR_JUGADOR, "Tú"), (COLOR_SALIDA, "Salida"),
                             (COLOR_PATRULLERO, "Patrullero"), (COLOR_CAZADOR, "Cazador"),
                             (COLOR_PISTA, "Pista")):
            fila = tk.Frame(leyenda, bg=PANEL)
            fila.pack(anchor="w")
            tk.Label(fila, text="●", fg=color, bg=PANEL, font=(FUENTE, 13)).pack(side="left")
            tk.Label(fila, text=texto, fg=TEXTO_SUAVE, bg=PANEL, font=(FUENTE, 10)).pack(side="left")
        self._actualizar_panel()

    def _dato(self, padre, nombre):
        """Crea un par nombre/valor. Recibe: padre, nombre. Devuelve: Label del valor."""
        tk.Label(padre, text=nombre, bg=PANEL, fg=TEXTO_SUAVE, font=(FUENTE, 10)).pack(anchor="w")
        valor = tk.Label(padre, text="0", bg=PANEL, fg=TEXTO, font=(FUENTE, 15, "bold"))
        valor.pack(anchor="w", pady=(0, 6))
        return valor

    def _actualizar_panel(self):
        """Refresca los números del panel. Recibe/Devuelve: nada."""
        p = self.partida
        minutos, segundos = divmod(p.tiempo_restante, 60)
        self.lbl_tiempo.config(text="%d:%02d" % (minutos, segundos),
                               fg=COLOR_PELIGRO if p.tiempo_restante <= 20 else TEXTO)
        self.lbl_movs.config(text=str(p.movimientos))
        self.lbl_deshacer.config(text=str(p.deshaceres))
        self.lbl_pistas.config(text=str(p.pistas))

    # ------------------------------------------------------------ dibujo
    def _rect(self, celda, color, margen=0, tag="dinamico", ovalo=False):
        """
        Dibuja un cuadro u óvalo en una celda.
        Recibe: celda (tupla), color, margen (px), tag, ovalo (bool). Devuelve: nada.
        """
        f, c = celda
        t = self.celda
        x0, y0 = c * t + margen, f * t + margen
        x1, y1 = (c + 1) * t - margen, (f + 1) * t - margen
        crear = self.lienzo.create_oval if ovalo else self.lienzo.create_rectangle
        crear(x0, y0, x1, y1, fill=color, outline="", tags=tag)

    def _dibujar_tablero(self):
        """Dibuja paredes y salida (una sola vez). Recibe/Devuelve: nada."""
        lab = self.partida.laberinto
        for f in range(lab.filas):
            for c in range(lab.columnas):
                if lab.matriz[f][c] == PARED:
                    self._rect((f, c), COLOR_PARED, tag="fijo")
        self._rect(lab.salida, COLOR_SALIDA, tag="fijo")
        self._rect(lab.entrada, "#dfe3f3", tag="fijo")

    def _dibujar_dinamico(self):
        """Dibuja rastro, pista, enemigos y jugador. Recibe/Devuelve: nada."""
        self.lienzo.delete("dinamico")
        m = max(1, self.celda // 4)
        for celda in self.partida.camino:                 # ListaDoble
            self._rect(celda, COLOR_RASTRO, margen=m)
        if self.camino_pista is not None:                  # ListaDoble del BFS
            for celda in self.camino_pista:
                self._rect(celda, COLOR_PISTA, margen=m, ovalo=True)
        for enemigo in self.partida.enemigos:              # ListaCircular
            color = COLOR_CAZADOR if enemigo.tipo == "cazador" else COLOR_PATRULLERO
            self._rect(enemigo.posicion, color, margen=max(1, self.celda // 8), ovalo=True)
        self._rect(self.partida.jugador, COLOR_JUGADOR, margen=max(1, self.celda // 8), ovalo=True)
        if self.pausado:
            ancho = int(self.lienzo["width"])
            alto = int(self.lienzo["height"])
            self.lienzo.create_rectangle(0, alto // 2 - 40, ancho, alto // 2 + 40,
                                         fill=FONDO, outline="", tags="dinamico")
            self.lienzo.create_text(ancho // 2, alto // 2, text="PAUSA  —  presiona P",
                                    fill=TEXTO, font=(FUENTE, 22, "bold"), tags="dinamico")

    # ------------------------------------------------------------ acciones
    def _tecla(self, evento):
        """Procesa una tecla. Teclas desconocidas se ignoran. Recibe: evento."""
        tecla = evento.keysym
        if tecla in ("p", "P"):
            self.pausar()
        elif tecla == "Escape":
            self.volver_menu()
        elif self.pausado:
            return
        elif tecla in TECLAS_MOVIMIENTO:
            self.mover(*TECLAS_MOVIMIENTO[tecla])
        elif tecla in ("z", "Z", "BackSpace"):
            self.deshacer()
        elif tecla in ("h", "H"):
            self.mostrar_pista()

    def mover(self, df, dc):
        """Mueve al jugador. Recibe: df, dc. Devuelve: nada."""
        if self.pausado:
            return
        resultado = self.partida.mover(df, dc)
        if resultado == "pared":
            self.lbl_estado.config(text="Ahí hay una pared.")
        else:
            self.lbl_estado.config(text="")
        self._refrescar()

    def deshacer(self):
        """Deshace el último movimiento (Pila). Recibe/Devuelve: nada."""
        if self.pausado:
            return
        if not self.partida.deshacer():
            self.lbl_estado.config(text="No hay movimientos para deshacer.")
        else:
            self.lbl_estado.config(text="Movimiento deshecho (-%d pts)." % PENALIZACION_DESHACER)
        self._refrescar()

    def mostrar_pista(self):
        """Muestra 3 segundos el camino más corto (BFS). Recibe/Devuelve: nada."""
        if self.pausado or self.partida.estado != JUGANDO:
            return
        self.camino_pista = self.partida.pista()
        self.lbl_estado.config(text="Pista: %d pasos hasta la salida (-%d pts)."
                               % (self.camino_pista.tamano() - 1, PENALIZACION_PISTA))
        if self._id_pista is not None:
            self.after_cancel(self._id_pista)
        self._id_pista = self.after(3000, self._ocultar_pista)
        self._refrescar()

    def _ocultar_pista(self):
        """Borra la pista de la pantalla. Recibe/Devuelve: nada."""
        self.camino_pista = None
        self._id_pista = None
        self._dibujar_dinamico()

    def pausar(self):
        """Pausa o reanuda. Recibe/Devuelve: nada."""
        self.pausado = not self.pausado
        self._dibujar_dinamico()

    def rendirse(self):
        """Termina la partida si el jugador confirma. Recibe/Devuelve: nada."""
        estaba = self.pausado
        self.pausado = True            # el juego se detiene mientras se pregunta
        if messagebox.askyesno("Rendirse", "¿Seguro que quieres rendirte?"):
            self.partida.rendirse()
        self.pausado = estaba
        self._refrescar()

    def volver_menu(self):
        """Vuelve al menú si el jugador confirma. Recibe/Devuelve: nada."""
        estaba = self.pausado
        self.pausado = True
        if messagebox.askyesno("Menú", "¿Salir al menú? Se perderá la partida."):
            self.app.mostrar(MenuPrincipal)
        else:
            self.pausado = estaba
            self._dibujar_dinamico()

    # ------------------------------------------------------------ ciclo
    def _reloj(self):
        """Se ejecuta cada segundo. Recibe/Devuelve: nada."""
        if not self.pausado:
            self.partida.pasar_segundo()
            self._refrescar()
        if self.partida.estado == JUGANDO:
            self._id_reloj = self.after(1000, self._reloj)

    def _turno_enemigos(self):
        """Mueve a los enemigos periódicamente. Recibe/Devuelve: nada."""
        if not self.pausado:
            self.partida.mover_enemigos()
            self._refrescar()
        if self.partida.estado == JUGANDO:
            self._id_enemigos = self.after(self.partida.config["velocidad_ms"],
                                           self._turno_enemigos)

    def _refrescar(self):
        """Redibuja y revisa si terminó la partida. Recibe/Devuelve: nada."""
        self._actualizar_panel()
        self._dibujar_dinamico()
        if self.partida.estado != JUGANDO and not self._terminado:
            self._terminado = True
            self.cerrar()
            self.after(600, lambda: self.app.mostrar(PantallaResultado, partida=self.partida))

    def cerrar(self):
        """Cancela todos los temporizadores. Recibe/Devuelve: nada."""
        for id_ in (self._id_reloj, self._id_enemigos, self._id_pista):
            if id_ is not None:
                try:
                    self.after_cancel(id_)
                except (tk.TclError, ValueError):
                    pass
        self._id_reloj = self._id_enemigos = self._id_pista = None


# ================================================================= RESULTADO
class PantallaResultado(Pantalla):
    """Muestra si ganó o perdió, el puntaje y permite guardar el récord."""

    def __init__(self, app, partida):
        """Recibe: app, partida (Partida terminada). Devuelve: nada."""
        super().__init__(app)
        self.partida = partida
        gano = partida.estado == GANADO
        caja = tk.Frame(self, bg=FONDO)
        caja.place(relx=0.5, rely=0.5, anchor="center")
        titulo(caja, "¡GANASTE!" if gano else "PERDISTE", 40).pack()
        tk.Label(caja, text=partida.motivo, bg=FONDO, fg=COLOR_SALIDA if gano else COLOR_PELIGRO,
                 font=(FUENTE, 15)).pack(pady=(0, 16))

        datos = tk.Frame(caja, bg=PANEL, padx=24, pady=14)
        datos.pack(pady=(0, 16))
        filas = (("Nivel", partida.nivel), ("Tiempo usado", "%d s" % partida.tiempo_usado()),
                 ("Movimientos", partida.movimientos), ("Pistas", partida.pistas),
                 ("Deshacer", partida.deshaceres), ("Puntaje", partida.puntaje()))
        for i, (k, v) in enumerate(filas):
            tk.Label(datos, text=k, bg=PANEL, fg=TEXTO_SUAVE, font=(FUENTE, 12)).grid(
                row=i, column=0, sticky="w", padx=(0, 30))
            tk.Label(datos, text=str(v), bg=PANEL, fg=TEXTO, font=(FUENTE, 12, "bold")).grid(
                row=i, column=1, sticky="e")

        self.guardado = False
        if gano:
            tk.Label(caja, text="Escribe tu nombre para guardar el puntaje:", bg=FONDO,
                     fg=TEXTO, font=(FUENTE, 12)).pack()
            self.entrada = tk.Entry(caja, font=(FUENTE, 14), justify="center", width=20)
            self.entrada.pack(pady=6)
            self.entrada.bind("<Return>", lambda e: self.guardar())
            self.lbl_error = tk.Label(caja, text="", bg=FONDO, fg=COLOR_PELIGRO, font=(FUENTE, 11))
            self.lbl_error.pack()
            boton(caja, "💾 Guardar puntaje", self.guardar).pack(pady=4)
            self.after(50, self.entrada.focus_set)
        boton(caja, "⏯ Ver repetición", lambda: app.mostrar(PantallaRepeticion, partida=partida)).pack(pady=4)
        boton(caja, "↻ Jugar otra vez", lambda: app.mostrar(PantallaJuego, nivel=partida.nivel)).pack(pady=4)
        boton(caja, "← Menú principal", lambda: app.mostrar(MenuPrincipal), color="#555d85").pack(pady=4)

    def guardar(self):
        """
        Valida el nombre y guarda el récord en el árbol (y en el archivo).
        Recibe/Devuelve: nada.
        """
        if self.guardado:
            self.lbl_error.config(text="Ya guardaste este puntaje.", fg=TEXTO_SUAVE)
            return
        ok, resultado = validar_nombre(self.entrada.get())
        if not ok:
            self.lbl_error.config(text=resultado, fg=COLOR_PELIGRO)
            return
        p = self.partida
        record = Record(resultado, p.puntaje(), p.nivel, p.tiempo_usado(), p.movimientos)
        if self.app.records.agregar(record):
            self.lbl_error.config(text="¡Guardado!", fg=COLOR_SALIDA)
        else:
            self.lbl_error.config(text="Se guardó en memoria, pero no en el archivo.", fg=COLOR_PISTA)
        self.guardado = True


# ================================================================ REPETICIÓN
class PantallaRepeticion(Pantalla):
    """
    Reproduce el camino del jugador paso a paso. Usa directamente los
    nodos de la ListaDoble: 'siguiente' para avanzar y 'anterior' para
    retroceder, cada paso en O(1).
    """

    def __init__(self, app, partida):
        """Recibe: app, partida. Devuelve: nada."""
        super().__init__(app)
        self.partida = partida
        self.nodo = partida.camino.cabeza
        self.indice = 0
        self.total = partida.camino.tamano()
        self._id_auto = None

        lab = partida.laberinto
        self.celda = max(8, min(ANCHO_LIENZO // lab.columnas, (ALTO_LIENZO - 40) // lab.filas))
        titulo(self, "Repetición del camino", 20).pack(pady=(12, 4))
        self.lbl_paso = tk.Label(self, text="", bg=FONDO, fg=TEXTO_SUAVE, font=(FUENTE, 12))
        self.lbl_paso.pack()
        self.lienzo = tk.Canvas(self, width=self.celda * lab.columnas, height=self.celda * lab.filas,
                                bg=COLOR_PISO, highlightthickness=0)
        self.lienzo.pack(pady=8)
        for f in range(lab.filas):
            for c in range(lab.columnas):
                if lab.matriz[f][c] == PARED:
                    self._rect((f, c), COLOR_PARED, tag="fijo")
        self._rect(lab.salida, COLOR_SALIDA, tag="fijo")

        controles = tk.Frame(self, bg=FONDO)
        controles.pack(pady=4)
        boton(controles, "⏮", self.inicio, ancho=4).pack(side="left", padx=3)
        boton(controles, "◀", self.atras, ancho=4).pack(side="left", padx=3)
        self.btn_auto = boton(controles, "▶ Reproducir", self.auto, ancho=12)
        self.btn_auto.pack(side="left", padx=3)
        boton(controles, "▶", self.adelante, ancho=4).pack(side="left", padx=3)
        boton(controles, "⏭", self.final, ancho=4).pack(side="left", padx=3)
        boton(controles, "← Menú", lambda: app.mostrar(MenuPrincipal), color="#555d85",
              ancho=8).pack(side="left", padx=(18, 3))
        app.bind("<KeyPress>", self._tecla)
        self._dibujar()

    def _rect(self, celda, color, margen=0, tag="dinamico", ovalo=False):
        """Dibuja en una celda. Recibe: celda, color, margen, tag, ovalo."""
        f, c = celda
        t = self.celda
        crear = self.lienzo.create_oval if ovalo else self.lienzo.create_rectangle
        crear(c * t + margen, f * t + margen, (c + 1) * t - margen, (f + 1) * t - margen,
              fill=color, outline="", tags=tag)

    def _dibujar(self):
        """Dibuja el camino hasta el nodo actual. Recibe/Devuelve: nada."""
        self.lienzo.delete("dinamico")
        m = max(1, self.celda // 4)
        nodo = self.partida.camino.cabeza
        while nodo is not None and nodo is not self.nodo:
            self._rect(nodo.dato, COLOR_RASTRO, margen=m)
            nodo = nodo.siguiente
        if self.nodo is not None:
            self._rect(self.nodo.dato, COLOR_JUGADOR, margen=max(1, self.celda // 8), ovalo=True)
        self.lbl_paso.config(text="Paso %d de %d   (flechas ← → para moverte)"
                             % (self.indice, self.total - 1))

    def adelante(self):
        """Avanza un paso (nodo.siguiente). Devuelve: True si avanzó."""
        if self.nodo is not None and self.nodo.siguiente is not None:
            self.nodo = self.nodo.siguiente
            self.indice += 1
            self._dibujar()
            return True
        return False

    def atras(self):
        """Retrocede un paso (nodo.anterior). Recibe/Devuelve: nada."""
        if self.nodo is not None and self.nodo.anterior is not None:
            self.nodo = self.nodo.anterior
            self.indice -= 1
            self._dibujar()

    def inicio(self):
        """Va al primer paso (cabeza). Recibe/Devuelve: nada."""
        self.nodo = self.partida.camino.cabeza
        self.indice = 0
        self._dibujar()

    def final(self):
        """Va al último paso (cola). Recibe/Devuelve: nada."""
        self.nodo = self.partida.camino.cola
        self.indice = self.total - 1
        self._dibujar()

    def auto(self):
        """Reproduce o detiene la repetición automática. Recibe/Devuelve: nada."""
        if self._id_auto is not None:
            self.cerrar()
            return
        if self.nodo is self.partida.camino.cola:
            self.inicio()
        self.btn_auto.config(text="⏸ Detener")
        self._paso_auto()

    def _paso_auto(self):
        """Un paso de la reproducción automática."""
        if self.adelante():
            self._id_auto = self.after(120, self._paso_auto)
        else:
            self.cerrar()

    def _tecla(self, evento):
        """Flechas para navegar, Esc para salir. Recibe: evento."""
        if evento.keysym == "Right":
            self.adelante()
        elif evento.keysym == "Left":
            self.atras()
        elif evento.keysym == "Escape":
            self.app.mostrar(MenuPrincipal)

    def cerrar(self):
        """Detiene la reproducción automática."""
        if self._id_auto is not None:
            try:
                self.after_cancel(self._id_auto)
            except (tk.TclError, ValueError):
                pass
            self._id_auto = None
        try:
            self.btn_auto.config(text="▶ Reproducir")
        except tk.TclError:
            pass


# =================================================================== RÉCORDS
class PantallaRecords(Pantalla):
    """Tabla de mejores puntajes (Árbol BST)."""

    FILTROS = ("Todos",) + tuple(NIVELES)

    def __init__(self, app):
        """Recibe: app. Devuelve: nada."""
        super().__init__(app)
        self.filtro = tk.StringVar(value="Todos")
        self.mostrados = None   # ListaDoble con los récords que se ven en la tabla

        titulo(self, "Mejores puntajes").pack(pady=(18, 6))
        cuerpo = tk.Frame(self, bg=FONDO)
        cuerpo.pack(expand=True, fill="both", padx=30)

        izquierda = tk.Frame(cuerpo, bg=FONDO)
        izquierda.pack(side="left", fill="both", expand=True)
        filtros = tk.Frame(izquierda, bg=FONDO)
        filtros.pack(anchor="w", pady=(0, 6))
        tk.Label(filtros, text="Nivel:", bg=FONDO, fg=TEXTO, font=(FUENTE, 11)).pack(side="left")
        for nombre in self.FILTROS:
            tk.Radiobutton(filtros, text=nombre, value=nombre, variable=self.filtro,
                           command=self.refrescar, bg=FONDO, fg=TEXTO, selectcolor=PANEL,
                           activebackground=FONDO, font=(FUENTE, 11)).pack(side="left", padx=4)
        tk.Label(izquierda, text="  #   Nombre            Puntaje   Nivel     Tiempo  Movs",
                 bg=FONDO, fg=TEXTO_SUAVE, font=("Consolas", 11), anchor="w").pack(fill="x")
        self.tabla = tk.Listbox(izquierda, font=("Consolas", 11), bg=PANEL, fg=TEXTO,
                                selectbackground=COLOR_BOTON, height=18, activestyle="none",
                                highlightthickness=0, borderwidth=0)
        self.tabla.pack(fill="both", expand=True)

        derecha = tk.Frame(cuerpo, bg=PANEL, padx=14, pady=14)
        derecha.pack(side="left", fill="y", padx=(16, 0))
        tk.Label(derecha, text="Buscar puntaje (BST)", bg=PANEL, fg=TEXTO,
                 font=(FUENTE, 11, "bold")).pack(anchor="w")
        self.entrada = tk.Entry(derecha, font=(FUENTE, 12), width=14)
        self.entrada.pack(anchor="w", pady=4)
        self.entrada.bind("<Return>", lambda e: self.buscar())
        boton(derecha, "🔍 Buscar", self.buscar, ancho=16).pack(pady=3)
        boton(derecha, "🗑 Eliminar seleccionado", self.eliminar, color=COLOR_PELIGRO,
              ancho=16).pack(pady=3)
        self.lbl_mensaje = tk.Label(derecha, text="", bg=PANEL, fg=COLOR_PISTA, wraplength=200,
                                    justify="left", font=(FUENTE, 10))
        self.lbl_mensaje.pack(anchor="w", pady=(6, 10))
        tk.Label(derecha, text="Recorridos del árbol", bg=PANEL, fg=TEXTO,
                 font=(FUENTE, 11, "bold")).pack(anchor="w")
        self.lbl_recorridos = tk.Label(derecha, text="", bg=PANEL, fg=TEXTO_SUAVE, wraplength=220,
                                       justify="left", font=("Consolas", 9))
        self.lbl_recorridos.pack(anchor="w")

        boton(self, "← Volver al menú", lambda: app.mostrar(MenuPrincipal)).pack(pady=12)
        app.bind("<KeyPress>", lambda e: app.mostrar(MenuPrincipal) if e.keysym == "Escape" else None)
        self.refrescar()

    def refrescar(self):
        """
        Llena la tabla de mayor a menor: inorden del árbol en una
        ListaDoble y luego recorrido hacia atrás. Recibe/Devuelve: nada.
        """
        self.tabla.delete(0, "end")
        filtro = self.filtro.get()
        self.mostrados = ListaDoble()

        def agregar(rec):
            if filtro == "Todos" or rec.nivel == filtro:
                self.mostrados.insertar_final(rec)
                self.tabla.insert("end", " %2d   %-15s %8d   %-8s %5d s  %4d" % (
                    self.mostrados.tamano(), rec.nombre, rec.puntaje, rec.nivel,
                    rec.tiempo, rec.movimientos))

        self.app.records.ordenados().recorrer_atras(agregar)
        if self.mostrados.esta_vacia():
            self.tabla.insert("end", "  (todavía no hay puntajes: ¡gana una partida!)")
        r = self.app.records
        self.lbl_recorridos.config(text="Nodos: %d   Altura: %d\n\nInorden:\n%s\n\nPreorden:\n%s\n\nPosorden:\n%s" % (
            r.arbol.tamano(), r.arbol.altura(), r.recorrido_texto("inorden"),
            r.recorrido_texto("preorden"), r.recorrido_texto("posorden")))

    def buscar(self):
        """Busca un puntaje exacto en el árbol. Recibe/Devuelve: nada."""
        ok, valor = validar_entero(self.entrada.get())
        if not ok:
            self.lbl_mensaje.config(text=valor, fg=COLOR_PELIGRO)
            return
        rec = self.app.records.buscar(valor)
        if rec is None:
            self.lbl_mensaje.config(text="No hay ningún récord con %d puntos." % valor, fg=COLOR_PISTA)
        else:
            self.lbl_mensaje.config(text="Encontrado: %s, nivel %s, %d s."
                                    % (rec.nombre, rec.nivel, rec.tiempo), fg=COLOR_SALIDA)

    def eliminar(self):
        """Elimina del árbol el récord seleccionado. Recibe/Devuelve: nada."""
        seleccion = self.tabla.curselection()
        if not seleccion or self.mostrados.esta_vacia():
            self.lbl_mensaje.config(text="Primero selecciona un récord de la tabla.", fg=COLOR_PELIGRO)
            return
        indice = seleccion[0]
        if indice >= self.mostrados.tamano():
            return
        rec = self.mostrados.obtener(indice)
        if messagebox.askyesno("Eliminar", "¿Eliminar el récord de %s (%d pts)?" % (rec.nombre, rec.puntaje)):
            self.app.records.eliminar(rec)
            self.lbl_mensaje.config(text="Récord eliminado.", fg=COLOR_SALIDA)
            self.refrescar()
