"""
Enemigos del laberinto.

- Patrullero: sigue una ruta fija guardada en una ListaCircular. La ruta
  va de un punto A a un punto B y regresa, y como la lista es circular
  el enemigo la repite indefinidamente con solo llamar a avanzar().
- Cazador (solo nivel Difícil): cada cierto número de turnos calcula con
  BFS (Cola) el camino más corto hacia el jugador y da un paso.
"""
from estructuras import ListaCircular


class Enemigo:
    """Clase base: un enemigo tiene una posición y sabe dar un paso."""

    tipo = "enemigo"

    def __init__(self, posicion):
        """Recibe: posicion (tupla fila, columna). Devuelve: nada."""
        self.posicion = posicion
        self.anterior = posicion

    def paso(self, laberinto, jugador):
        """
        Mueve al enemigo un paso (lo redefinen las subclases).
        Recibe: laberinto (Laberinto), jugador (tupla). Devuelve: nada.
        """
        raise NotImplementedError


class Patrullero(Enemigo):
    """Enemigo que recorre una ruta circular."""

    tipo = "patrullero"

    def __init__(self, ruta):
        """
        Recibe: ruta (ListaCircular de celdas, no vacía). Devuelve: nada.
        """
        self.ruta = ruta
        super().__init__(ruta.avanzar())

    @staticmethod
    def crear_ruta(laberinto, inicio, fin, max_pasos=14):
        """
        Construye la ruta ida y vuelta entre dos celdas.
        Recibe: laberinto, inicio y fin (tuplas), max_pasos (int).
        Devuelve: ListaCircular con la ruta, o None si es muy corta.
        Ejemplo: camino A,B,C,D  ->  ruta circular A,B,C,D,C,B (y vuelve a A).
        """
        camino = laberinto.camino_mas_corto(inicio, fin)
        if camino is None or camino.tamano() < 4:
            return None
        ruta = ListaCircular()
        # ida (recortada a max_pasos)
        nodo = camino.cabeza
        contador = 0
        while nodo is not None and contador < max_pasos:
            ruta.insertar_final(nodo.dato)
            ultimo = nodo
            nodo = nodo.siguiente
            contador += 1
        # vuelta: desde el penúltimo de la ida hasta el segundo
        nodo = ultimo.anterior
        while nodo is not None and nodo is not camino.cabeza:
            ruta.insertar_final(nodo.dato)
            nodo = nodo.anterior
        return ruta

    def paso(self, laberinto, jugador):
        """Avanza al siguiente nodo de la ruta circular. Devuelve: nada."""
        self.anterior = self.posicion
        self.posicion = self.ruta.avanzar()


class Cazador(Enemigo):
    """Enemigo que persigue al jugador usando BFS."""

    tipo = "cazador"

    def __init__(self, posicion, lentitud=2):
        """
        Recibe: posicion (tupla), lentitud (int: se mueve 1 de cada
        'lentitud' turnos, para que el jugador tenga oportunidad).
        Devuelve: nada.
        """
        super().__init__(posicion)
        self.lentitud = max(1, lentitud)
        self._turno = 0

    def paso(self, laberinto, jugador):
        """
        Si le toca, da un paso por el camino más corto hacia el jugador.
        Recibe: laberinto, jugador (tupla). Devuelve: nada.
        """
        self.anterior = self.posicion
        self._turno = (self._turno + 1) % self.lentitud
        if self._turno != 0:
            return
        camino = laberinto.camino_mas_corto(self.posicion, jugador)
        if camino is not None and camino.tamano() >= 2:
            self.posicion = camino.obtener(1)
