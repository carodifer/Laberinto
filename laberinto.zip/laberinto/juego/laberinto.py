"""
Tablero del laberinto: generación con backtracking (Pila) y camino más
corto con búsqueda en anchura (Cola).

El laberinto es una matriz de filas x columnas (ambas impares) donde
PARED = 1 y LIBRE = 0. Las celdas con fila y columna impares son
"cuartos"; entre dos cuartos vecinos puede haber pared o pasillo.

Nota: la matriz del tablero es un arreglo 2D (no es una de las cinco
estructuras evaluadas); las cinco estructuras están en /estructuras.
"""
import random

from estructuras import Pila, Cola, ListaDoble

PARED = 1
LIBRE = 0

# (cambio de fila, cambio de columna): arriba, abajo, izquierda, derecha
DIRECCIONES = ((-1, 0), (1, 0), (0, -1), (0, 1))


class Laberinto:
    """Guarda la matriz del laberinto y ofrece generación y búsqueda."""

    def __init__(self, filas, columnas, semilla=None, atajos=0.0):
        """
        Crea y genera un laberinto.
        Recibe: filas y columnas (int, se vuelven impares y mínimo 5),
                semilla (int o None, para repetir el mismo laberinto),
                atajos (float 0..1, fracción de paredes internas que se
                tumban para crear caminos alternativos).
        Devuelve: nada.
        """
        self.filas = max(5, filas if filas % 2 == 1 else filas + 1)
        self.columnas = max(5, columnas if columnas % 2 == 1 else columnas + 1)
        self._azar = random.Random(semilla)
        self.matriz = [[PARED] * self.columnas for _ in range(self.filas)]
        self.entrada = (1, 1)
        self.salida = (self.filas - 2, self.columnas - 2)
        self.generar()
        if atajos > 0:
            self._abrir_atajos(atajos)

    # ------------------------------------------------------------ generación
    def generar(self):
        """
        Genera un laberinto perfecto con backtracking iterativo usando Pila:
          1. Se apila la entrada y se marca como libre.
          2. Mientras la pila no esté vacía: se mira el tope; si tiene
             vecinos (a 2 celdas) sin visitar, se elige uno al azar, se
             tumba la pared del medio y se apila. Si no tiene, se desapila
             (backtracking: se regresa a la celda anterior).
        Recibe: nada. Devuelve: nada.
        Complejidad: O(filas * columnas).
        """
        pila = Pila()
        f, c = self.entrada
        self.matriz[f][c] = LIBRE
        pila.apilar(self.entrada)
        while not pila.esta_vacia():
            f, c = pila.ver_tope()
            direcciones = list(DIRECCIONES)  # copia local para barajar
            self._azar.shuffle(direcciones)
            avanzo = False
            for df, dc in direcciones:
                nf, nc = f + 2 * df, c + 2 * dc
                if 0 < nf < self.filas - 1 and 0 < nc < self.columnas - 1 \
                        and self.matriz[nf][nc] == PARED:
                    self.matriz[f + df][c + dc] = LIBRE   # pared del medio
                    self.matriz[nf][nc] = LIBRE
                    pila.apilar((nf, nc))
                    avanzo = True
                    break
            if not avanzo:
                pila.desapilar()

    def _abrir_atajos(self, fraccion):
        """
        Tumba algunas paredes internas para que haya más de un camino
        (así se puede esquivar a los enemigos).
        Recibe: fraccion (float). Devuelve: nada.
        """
        for f in range(1, self.filas - 1):
            for c in range(1, self.columnas - 1):
                if self.matriz[f][c] != PARED:
                    continue
                horizontal = self.matriz[f][c - 1] == LIBRE and self.matriz[f][c + 1] == LIBRE \
                    and self.matriz[f - 1][c] == PARED and self.matriz[f + 1][c] == PARED
                vertical = self.matriz[f - 1][c] == LIBRE and self.matriz[f + 1][c] == LIBRE \
                    and self.matriz[f][c - 1] == PARED and self.matriz[f][c + 1] == PARED
                if (horizontal or vertical) and self._azar.random() < fraccion:
                    self.matriz[f][c] = LIBRE

    # ------------------------------------------------------------- consultas
    def es_libre(self, celda):
        """
        Recibe: celda (tupla fila, columna).
        Devuelve: True si está dentro del tablero y no es pared.
        """
        f, c = celda
        return 0 <= f < self.filas and 0 <= c < self.columnas and self.matriz[f][c] == LIBRE

    def vecinos(self, celda):
        """
        Celdas libres adyacentes (arriba, abajo, izquierda, derecha).
        Recibe: celda (tupla). Devuelve: generador de tuplas.
        """
        f, c = celda
        for df, dc in DIRECCIONES:
            v = (f + df, c + dc)
            if self.es_libre(v):
                yield v

    def celda_libre_al_azar(self):
        """Recibe: nada. Devuelve: una celda libre (tupla) elegida al azar."""
        while True:
            f = self._azar.randrange(1, self.filas - 1)
            c = self._azar.randrange(1, self.columnas - 1)
            if self.matriz[f][c] == LIBRE:
                return (f, c)

    # ------------------------------------------------------------------ BFS
    def camino_mas_corto(self, origen, destino, prohibidas=None):
        """
        Búsqueda en anchura (BFS) con Cola:
          1. Se encola el origen.
          2. Se desencola una celda; se encolan sus vecinos no visitados
             guardando de dónde se llegó (padre).
          3. Al desencolar el destino, se reconstruye el camino yendo de
             padre en padre e insertando al inicio de una ListaDoble.
        Como la cola procesa por "capas", el primer camino que llega al
        destino es el más corto.
        Recibe: origen y destino (tuplas), prohibidas (matriz de bool o
                None: celdas por las que no se puede pasar).
        Devuelve: ListaDoble con las celdas desde origen hasta destino
                  (incluidos), o None si no hay camino.
        Complejidad: O(filas * columnas).
        """
        if not self.es_libre(origen) or not self.es_libre(destino):
            return None
        padre = [[None] * self.columnas for _ in range(self.filas)]
        visitado = [[False] * self.columnas for _ in range(self.filas)]
        cola = Cola()
        cola.encolar(origen)
        visitado[origen[0]][origen[1]] = True
        while not cola.esta_vacia():
            actual = cola.desencolar()
            if actual == destino:
                camino = ListaDoble()
                paso = destino
                while paso is not None:
                    camino.insertar_inicio(paso)
                    paso = padre[paso[0]][paso[1]]
                return camino
            for v in self.vecinos(actual):
                if not visitado[v[0]][v[1]] and \
                        (prohibidas is None or not prohibidas[v[0]][v[1]]):
                    visitado[v[0]][v[1]] = True
                    padre[v[0]][v[1]] = actual
                    cola.encolar(v)
        return None

    def distancia(self, origen, destino):
        """
        Recibe: origen y destino (tuplas).
        Devuelve: número de pasos del camino más corto, o -1 si no hay.
        """
        camino = self.camino_mas_corto(origen, destino)
        return -1 if camino is None else camino.tamano() - 1
