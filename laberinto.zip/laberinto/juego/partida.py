"""
Lógica de una partida (sin interfaz gráfica, para poder probarla sola).

Estructuras que usa:
  - Pila:           deshacer movimientos.
  - ListaDoble:     camino recorrido (para la repetición) y pistas.
  - ListaCircular:  conjunto de enemigos y rutas de patrulla.
  - Cola:           (dentro del Laberinto) BFS para pistas y cazador.
"""
import time

from estructuras import Pila, ListaDoble, ListaCircular
from .laberinto import Laberinto
from .enemigo import Patrullero, Cazador

JUGANDO = "jugando"
GANADO = "ganado"
PERDIDO = "perdido"

# Configuración de cada nivel
NIVELES = {
    "Fácil": {"filas": 15, "columnas": 21, "patrulleros": 2, "cazador": False,
              "tiempo": 120, "atajos": 0.12, "velocidad_ms": 450, "multiplicador": 1},
    "Medio": {"filas": 21, "columnas": 31, "patrulleros": 4, "cazador": False,
              "tiempo": 150, "atajos": 0.14, "velocidad_ms": 380, "multiplicador": 2},
    "Difícil": {"filas": 25, "columnas": 39, "patrulleros": 5, "cazador": True,
                "tiempo": 180, "atajos": 0.16, "velocidad_ms": 330, "multiplicador": 3},
}

PENALIZACION_PISTA = 50
PENALIZACION_DESHACER = 5
DISTANCIA_SEGURA = 10   # los enemigos aparecen al menos a esta distancia


class Partida:
    """Estado completo de una partida de laberinto."""

    def __init__(self, nivel="Fácil", semilla=None):
        """
        Crea una partida nueva.
        Recibe: nivel (str: 'Fácil', 'Medio' o 'Difícil'),
                semilla (int o None).
        Devuelve: nada. Lanza ValueError si el nivel no existe.
        """
        if nivel not in NIVELES:
            raise ValueError("Nivel inválido: %r" % (nivel,))
        self.nivel = nivel
        self.config = NIVELES[nivel]
        self.laberinto = Laberinto(self.config["filas"], self.config["columnas"],
                                   semilla=semilla, atajos=self.config["atajos"])
        self.jugador = self.laberinto.entrada
        self.estado = JUGANDO
        self.motivo = ""
        self.movimientos = 0
        self.deshaceres = 0
        self.pistas = 0
        self.tiempo_restante = self.config["tiempo"]
        self.historial = Pila()            # posiciones anteriores (deshacer)
        self.camino = ListaDoble()         # camino actual del jugador
        self.camino.insertar_final(self.jugador)
        self.enemigos = ListaCircular()
        self._crear_enemigos()

    # -------------------------------------------------------------- enemigos
    def _crear_enemigos(self):
        """
        Ubica patrulleros (y el cazador en Difícil) lejos de la entrada.
        Regla de "justicia": una ruta solo se acepta si, sumando todas las
        rutas, todavía existe un camino entrada -> salida que no pisa
        ninguna ruta de patrulla (se comprueba con BFS). Así el laberinto
        siempre se puede ganar esquivando a los patrulleros.
        Recibe: nada. Devuelve: nada.
        """
        lab = self.laberinto
        ocupadas = [[False] * lab.columnas for _ in range(lab.filas)]
        creados = 0
        intentos = 0
        while creados < self.config["patrulleros"] and intentos < 800:
            intentos += 1
            a = lab.celda_libre_al_azar()
            b = lab.celda_libre_al_azar()
            if lab.distancia(lab.entrada, a) < DISTANCIA_SEGURA:
                continue
            ruta = Patrullero.crear_ruta(lab, a, b)
            if ruta is None:
                continue
            seguro = True
            for celda in ruta:
                # ni cerca de la entrada ni encima de la salida
                if abs(celda[0] - 1) + abs(celda[1] - 1) < DISTANCIA_SEGURA // 2 \
                        or celda == lab.salida:
                    seguro = False
                    break
            if not seguro:
                continue
            for celda in ruta:
                ocupadas[celda[0]][celda[1]] = True
            if lab.camino_mas_corto(lab.entrada, lab.salida, ocupadas) is None:
                for celda in ruta:          # bloquearía la salida: se descarta
                    ocupadas[celda[0]][celda[1]] = False
                # (si otra ruta ya marcó la misma celda, se vuelve a marcar abajo)
                for enemigo in self.enemigos:
                    for celda in enemigo.ruta:
                        ocupadas[celda[0]][celda[1]] = True
                continue
            self.enemigos.insertar_final(Patrullero(ruta))
            creados += 1
        if self.config["cazador"]:
            # el cazador empieza cerca de la salida
            inicio = lab.salida
            camino = lab.camino_mas_corto(lab.salida, lab.entrada)
            if camino is not None and camino.tamano() > 6:
                inicio = camino.obtener(5)
            self.enemigos.insertar_final(Cazador(inicio, lentitud=2))

    def mover_enemigos(self):
        """
        Mueve todos los enemigos un paso y revisa si atraparon al jugador.
        Recibe: nada. Devuelve: True si el jugador fue atrapado.
        """
        if self.estado != JUGANDO:
            return False
        for enemigo in self.enemigos:
            enemigo.paso(self.laberinto, self.jugador)
        return self._revisar_choque()

    def _revisar_choque(self):
        """
        Pierde si algún enemigo está en la misma celda del jugador.
        (Jugador y enemigos se mueven en momentos distintos, así que no
        pueden "cruzarse" sin quedar en la misma celda.)
        Recibe: nada. Devuelve: True si perdió.
        """
        for enemigo in self.enemigos:
            if enemigo.posicion == self.jugador:
                self.estado = PERDIDO
                self.motivo = "¡Te atrapó un enemigo!"
                return True
        return False

    # --------------------------------------------------------------- jugador
    def mover(self, df, dc):
        """
        Intenta mover al jugador.
        Recibe: df, dc (int en -1, 0, 1: cambio de fila y columna).
        Devuelve: 'pared', 'movio', 'gano', 'atrapado' o 'fin' (la
                  partida ya terminó).
        """
        if self.estado != JUGANDO:
            return "fin"
        if (df, dc) not in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            return "pared"
        destino = (self.jugador[0] + df, self.jugador[1] + dc)
        if not self.laberinto.es_libre(destino):
            return "pared"
        self.historial.apilar(self.jugador)
        self.jugador = destino
        self.movimientos += 1
        self.camino.insertar_final(destino)
        if self._revisar_choque():
            return "atrapado"
        if destino == self.laberinto.salida:
            self.estado = GANADO
            self.motivo = "¡Encontraste la salida!"
            return "gano"
        return "movio"

    def deshacer(self):
        """
        Regresa al jugador a la posición anterior (desapila).
        Recibe: nada. Devuelve: True si pudo deshacer.
        """
        if self.estado != JUGANDO or self.historial.esta_vacia():
            return False
        self.jugador = self.historial.desapilar()
        self.camino.eliminar_final()
        self.deshaceres += 1
        self._revisar_choque()
        return True

    def pista(self):
        """
        Calcula con BFS el camino más corto a la salida. Cuesta puntos.
        Recibe: nada. Devuelve: ListaDoble con el camino (o None).
        """
        if self.estado != JUGANDO:
            return None
        self.pistas += 1
        return self.laberinto.camino_mas_corto(self.jugador, self.laberinto.salida)

    # ----------------------------------------------------------------- tiempo
    def pasar_segundo(self):
        """
        Descuenta un segundo. Si se acaba el tiempo, se pierde.
        Recibe: nada. Devuelve: el estado actual (str).
        """
        if self.estado == JUGANDO:
            self.tiempo_restante -= 1
            if self.tiempo_restante <= 0:
                self.tiempo_restante = 0
                self.estado = PERDIDO
                self.motivo = "¡Se acabó el tiempo!"
        return self.estado

    def rendirse(self):
        """Termina la partida como perdida. Recibe: nada. Devuelve: nada."""
        if self.estado == JUGANDO:
            self.estado = PERDIDO
            self.motivo = "Te rendiste."

    # ---------------------------------------------------------------- puntaje
    def puntaje(self):
        """
        Puntaje = (500 + 10 * segundos sobrantes - movimientos
                   - 50 * pistas - 5 * deshaceres) * multiplicador del nivel.
        Solo hay puntaje si se ganó. Nunca es negativo.
        Recibe: nada. Devuelve: int.
        """
        if self.estado != GANADO:
            return 0
        base = 500 + 10 * self.tiempo_restante - self.movimientos \
            - PENALIZACION_PISTA * self.pistas - PENALIZACION_DESHACER * self.deshaceres
        return max(0, base) * self.config["multiplicador"]

    def tiempo_usado(self):
        """Recibe: nada. Devuelve: segundos usados (int)."""
        return self.config["tiempo"] - self.tiempo_restante
