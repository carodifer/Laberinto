"""
Tabla de mejores puntajes guardada en un Árbol Binario de Búsqueda.

- Clave del árbol: el puntaje. Valor: un objeto Record.
- Mostrar de mayor a menor: recorrido inorden (menor a mayor) guardado
  en una ListaDoble, que luego se recorre hacia atrás.
- Guardar en archivo: recorrido PREORDEN. Al volver a cargar e insertar
  en ese mismo orden, el árbol queda con exactamente la misma forma.
"""
import os

from estructuras import ArbolBST, ListaDoble

SEPARADOR = ";"
LARGO_MAXIMO_NOMBRE = 15


class Record:
    """Un puntaje guardado."""

    def __init__(self, nombre, puntaje, nivel, tiempo, movimientos):
        """
        Recibe: nombre (str), puntaje (int), nivel (str), tiempo (int,
        segundos usados), movimientos (int). Devuelve: nada.
        """
        self.nombre = nombre
        self.puntaje = int(puntaje)
        self.nivel = nivel
        self.tiempo = int(tiempo)
        self.movimientos = int(movimientos)

    def __eq__(self, otro):
        """Dos récords son iguales si todos sus campos coinciden."""
        return isinstance(otro, Record) and \
            (self.nombre, self.puntaje, self.nivel, self.tiempo, self.movimientos) == \
            (otro.nombre, otro.puntaje, otro.nivel, otro.tiempo, otro.movimientos)

    def __repr__(self):
        return "Record(%s, %d, %s)" % (self.nombre, self.puntaje, self.nivel)

    def a_linea(self):
        """Recibe: nada. Devuelve: el récord como línea de texto para el archivo."""
        return SEPARADOR.join((self.nombre, str(self.puntaje), self.nivel,
                               str(self.tiempo), str(self.movimientos)))

    @staticmethod
    def desde_linea(linea):
        """
        Recibe: linea (str). Devuelve: Record, o None si la línea está dañada.
        """
        partes = linea.strip().split(SEPARADOR)
        if len(partes) != 5:
            return None
        try:
            return Record(partes[0], int(partes[1]), partes[2], int(partes[3]), int(partes[4]))
        except ValueError:
            return None


def validar_nombre(texto):
    """
    Revisa el nombre que escribe el jugador.
    Recibe: texto (str). Devuelve: (True, nombre_limpio) o (False, mensaje de error).
    """
    if texto is None:
        return False, "Escribe un nombre."
    nombre = texto.strip()
    if not nombre:
        return False, "El nombre no puede estar vacío."
    if len(nombre) > LARGO_MAXIMO_NOMBRE:
        return False, "Máximo %d caracteres." % LARGO_MAXIMO_NOMBRE
    if SEPARADOR in nombre or "\n" in nombre:
        return False, "El nombre no puede tener ';'."
    return True, nombre


def validar_entero(texto):
    """
    Recibe: texto (str). Devuelve: (True, entero) o (False, mensaje de error).
    """
    try:
        valor = int(str(texto).strip())
    except ValueError:
        return False, "Escribe un número entero."
    if valor < 0:
        return False, "El número no puede ser negativo."
    return True, valor


class GestorRecords:
    """Administra el árbol de récords y el archivo donde se guardan."""

    def __init__(self, ruta_archivo):
        """
        Recibe: ruta_archivo (str). Devuelve: nada. Carga los récords.
        """
        self.ruta = ruta_archivo
        self.arbol = ArbolBST()
        self.cargar()

    def cargar(self):
        """
        Lee el archivo línea por línea e inserta cada récord en el árbol.
        Las líneas dañadas se ignoran. Recibe: nada. Devuelve: nada.
        """
        self.arbol = ArbolBST()
        if not os.path.exists(self.ruta):
            return
        try:
            with open(self.ruta, "r", encoding="utf-8") as archivo:
                for linea in archivo:
                    record = Record.desde_linea(linea)
                    if record is not None:
                        self.arbol.insertar(record.puntaje, record)
        except OSError:
            pass  # si no se puede leer, se empieza con la tabla vacía

    def guardar(self):
        """
        Escribe el árbol en preorden. Recibe: nada.
        Devuelve: True si se guardó, False si hubo un error de archivo.
        """
        try:
            with open(self.ruta, "w", encoding="utf-8") as archivo:
                self.arbol.preorden(lambda clave, rec: archivo.write(rec.a_linea() + "\n"))
            return True
        except OSError:
            return False

    def agregar(self, record):
        """Recibe: record (Record). Devuelve: True si se guardó en disco."""
        self.arbol.insertar(record.puntaje, record)
        return self.guardar()

    def eliminar(self, record):
        """Recibe: record (Record). Devuelve: True si estaba y se eliminó."""
        ok = self.arbol.eliminar(record.puntaje, record)
        if ok:
            self.guardar()
        return ok

    def buscar(self, puntaje):
        """Recibe: puntaje (int). Devuelve: un Record con ese puntaje o None."""
        return self.arbol.buscar(puntaje)

    def ordenados(self):
        """
        Recibe: nada. Devuelve: ListaDoble con los récords de menor a mayor
        (recorrerla hacia atrás da de mayor a menor).
        """
        lista = ListaDoble()
        self.arbol.inorden(lambda clave, rec: lista.insertar_final(rec))
        return lista

    def recorrido_texto(self, tipo):
        """
        Texto con las claves en el recorrido pedido (para mostrarlo en
        pantalla y explicarlo en la sustentación).
        Recibe: tipo ('inorden', 'preorden' o 'posorden'). Devuelve: str.
        """
        partes = ListaDoble()
        visitar = lambda clave, rec: partes.insertar_final("%d" % clave)
        if tipo == "inorden":
            self.arbol.inorden(visitar)
        elif tipo == "preorden":
            self.arbol.preorden(visitar)
        elif tipo == "posorden":
            self.arbol.posorden(visitar)
        else:
            raise ValueError("Recorrido desconocido")
        return " → ".join(partes) if not partes.esta_vacia() else "(árbol vacío)"
