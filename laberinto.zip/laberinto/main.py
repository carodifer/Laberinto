"""
Punto de entrada del juego "Escape del Laberinto".

Ejecutar:  python main.py
Recibe: nada. Devuelve: nada (abre la ventana del juego).
"""
import os
import sys

CARPETA = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CARPETA)


def main():
    """Abre la ventana principal. Recibe/Devuelve: nada."""
    try:
        from interfaz.app import App
    except ImportError as error:
        print("No se pudo cargar Tkinter:", error)
        print("En Linux instálalo con: sudo apt install python3-tk")
        return
    app = App(os.path.join(CARPETA, "records.txt"))
    app.mainloop()


if __name__ == "__main__":
    main()
