"""
Pruebas unitarias de las cinco estructuras.
Ejecutar desde la carpeta del proyecto:  python -m unittest -v
"""
import unittest

from estructuras import Pila, Cola, ListaCircular, ListaDoble, ArbolBST


def a_texto(estructura_recorrer):
    """Ayuda: convierte un recorrido en texto. Recibe: función de recorrido. Devuelve: str."""
    partes = ListaDoble()
    estructura_recorrer(lambda *d: partes.insertar_final(str(d[0])))
    return ",".join(partes)


class TestPila(unittest.TestCase):
    def test_lifo(self):
        """Lo último que entra es lo primero que sale."""
        p = Pila()
        for x in (1, 2, 3):
            p.apilar(x)
        self.assertEqual(p.tamano(), 3)
        self.assertEqual(p.ver_tope(), 3)
        self.assertEqual(p.desapilar(), 3)
        self.assertEqual(p.desapilar(), 2)
        self.assertEqual(p.desapilar(), 1)
        self.assertTrue(p.esta_vacia())

    def test_vacia_lanza_error(self):
        """Desapilar o ver tope de una pila vacía lanza IndexError."""
        p = Pila()
        self.assertRaises(IndexError, p.desapilar)
        self.assertRaises(IndexError, p.ver_tope)


class TestCola(unittest.TestCase):
    def test_fifo(self):
        """Lo primero que entra es lo primero que sale."""
        c = Cola()
        for x in "abc":
            c.encolar(x)
        self.assertEqual(c.tamano(), 3)
        self.assertEqual(c.ver_frente(), "a")
        self.assertEqual(c.desencolar(), "a")
        c.encolar("d")
        self.assertEqual(c.desencolar(), "b")
        self.assertEqual(c.desencolar(), "c")
        self.assertEqual(c.desencolar(), "d")
        self.assertTrue(c.esta_vacia())
        c.encolar("e")                       # vuelve a funcionar tras vaciarse
        self.assertEqual(c.ver_frente(), "e")

    def test_vacia_lanza_error(self):
        c = Cola()
        self.assertRaises(IndexError, c.desencolar)
        self.assertRaises(IndexError, c.ver_frente)


class TestListaCircular(unittest.TestCase):
    def test_insertar_y_recorrer(self):
        """Insertar al inicio, final y en posición; recorrido de una vuelta."""
        l = ListaCircular()
        l.insertar_final(2)
        l.insertar_inicio(1)
        l.insertar_final(4)
        l.insertar_en_posicion(3, 2)
        l.insertar_en_posicion(0, 0)
        l.insertar_en_posicion(5, 5)
        self.assertEqual(a_texto(l.recorrer), "0,1,2,3,4,5")
        self.assertEqual(l.tamano(), 6)

    def test_es_circular(self):
        """avanzar() vuelve al inicio después del último."""
        l = ListaCircular()
        for x in "ABC":
            l.insertar_final(x)
        vistos = "".join(l.avanzar() for _ in range(7))
        self.assertEqual(vistos, "ABCABCA")

    def test_buscar_y_eliminar(self):
        l = ListaCircular()
        for x in (10, 20, 30, 40):
            l.insertar_final(x)
        self.assertEqual(l.buscar(30), 2)
        self.assertEqual(l.buscar(99), -1)
        self.assertTrue(l.eliminar(10))      # el primero
        self.assertTrue(l.eliminar(40))      # el último
        self.assertFalse(l.eliminar(99))
        self.assertEqual(a_texto(l.recorrer), "20,30")
        self.assertEqual(l.eliminar_en_posicion(1), 30)
        self.assertEqual(l.eliminar_en_posicion(0), 20)
        self.assertTrue(l.esta_vacia())
        self.assertRaises(IndexError, l.eliminar_en_posicion, 0)
        self.assertRaises(IndexError, l.avanzar)

    def test_eliminar_nodo_del_cursor(self):
        """Si se elimina el nodo del cursor, el cursor pasa al siguiente."""
        l = ListaCircular()
        for x in (1, 2, 3):
            l.insertar_final(x)
        l.avanzar(); l.avanzar()             # cursor en 2
        l.eliminar(2)
        self.assertEqual(l.actual(), 3)
        self.assertEqual(l.avanzar(), 1)


class TestListaDoble(unittest.TestCase):
    def test_insertar_y_recorrer_ambos_sentidos(self):
        d = ListaDoble()
        d.insertar_final("b")
        d.insertar_inicio("a")
        d.insertar_final("d")
        d.insertar_en_posicion("c", 2)
        self.assertEqual(a_texto(d.recorrer_adelante), "a,b,c,d")
        self.assertEqual(a_texto(d.recorrer_atras), "d,c,b,a")
        self.assertEqual(d.obtener(3), "d")
        self.assertEqual(d.obtener(1), "b")

    def test_enlaces_correctos(self):
        """Cada nodo apunta bien a su anterior y siguiente."""
        d = ListaDoble()
        for x in range(5):
            d.insertar_final(x)
        nodo = d.cabeza
        while nodo.siguiente is not None:
            self.assertIs(nodo.siguiente.anterior, nodo)
            nodo = nodo.siguiente
        self.assertIs(nodo, d.cola)

    def test_buscar_y_eliminar(self):
        d = ListaDoble()
        for x in (1, 2, 3, 4, 5):
            d.insertar_final(x)
        self.assertEqual(d.buscar(4), 3)
        self.assertEqual(d.buscar(9), -1)
        self.assertTrue(d.eliminar(3))
        self.assertEqual(d.eliminar_inicio(), 1)
        self.assertEqual(d.eliminar_final(), 5)
        self.assertEqual(a_texto(d.recorrer_adelante), "2,4")
        self.assertEqual(a_texto(d.recorrer_atras), "4,2")
        self.assertEqual(d.eliminar_en_posicion(1), 4)
        self.assertEqual(d.eliminar_en_posicion(0), 2)
        self.assertTrue(d.esta_vacia())
        self.assertIsNone(d.cola)
        self.assertRaises(IndexError, d.eliminar_final)
        self.assertRaises(IndexError, d.obtener, 0)


class TestArbolBST(unittest.TestCase):
    def setUp(self):
        #            50
        #         /      \
        #       30        70
        #      /  \      /  \
        #    20   40   60   80
        self.a = ArbolBST()
        for x in (50, 30, 70, 20, 40, 60, 80):
            self.a.insertar(x, "v%d" % x)

    def test_recorridos(self):
        self.assertEqual(a_texto(self.a.inorden), "20,30,40,50,60,70,80")
        self.assertEqual(a_texto(self.a.preorden), "50,30,20,40,70,60,80")
        self.assertEqual(a_texto(self.a.posorden), "20,40,30,60,80,70,50")
        self.assertEqual(self.a.altura(), 3)

    def test_buscar(self):
        self.assertEqual(self.a.buscar(60), "v60")
        self.assertIsNone(self.a.buscar(65))

    def test_eliminar_hoja_un_hijo_dos_hijos(self):
        self.assertTrue(self.a.eliminar(20))        # hoja
        self.assertTrue(self.a.eliminar(30))        # un hijo
        self.assertTrue(self.a.eliminar(50))        # dos hijos (raíz)
        self.assertFalse(self.a.eliminar(999))
        self.assertEqual(a_texto(self.a.inorden), "40,60,70,80")
        self.assertEqual(self.a.raiz.clave, 60)     # el sucesor ocupó la raíz
        self.assertEqual(self.a.tamano(), 4)

    def test_claves_repetidas(self):
        """Dos récords con el mismo puntaje: se elimina el correcto."""
        a = ArbolBST()
        a.insertar(100, "ana")
        a.insertar(100, "luis")
        a.insertar(90, "eva")
        self.assertEqual(a_texto(a.inorden), "90,100,100")
        self.assertTrue(a.eliminar(100, "luis"))
        self.assertEqual(a.buscar(100), "ana")
        self.assertFalse(a.eliminar(100, "luis"))


if __name__ == "__main__":
    unittest.main()
