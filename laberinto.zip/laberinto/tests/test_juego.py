"""
Pruebas de la lógica del juego (sin interfaz).
Ejecutar desde la carpeta del proyecto:  python -m unittest -v
"""
import os
import tempfile
import unittest

from estructuras import ListaCircular
from juego.laberinto import Laberinto, LIBRE
from juego.partida import Partida, NIVELES, GANADO, PERDIDO, JUGANDO
from juego.enemigo import Patrullero, Cazador
from juego.records import GestorRecords, Record, validar_nombre, validar_entero


def contar_libres(lab):
    """Ayuda: cuenta celdas libres. Recibe: Laberinto. Devuelve: int."""
    return sum(1 for fila in lab.matriz for x in fila if x == LIBRE)


class TestLaberinto(unittest.TestCase):
    def test_todo_conectado(self):
        """Desde la entrada se alcanza toda celda libre (generación correcta)."""
        for semilla in range(20):
            lab = Laberinto(15, 21, semilla=semilla)
            self.assertIsNotNone(lab.camino_mas_corto(lab.entrada, lab.salida))
            # BFS desde la entrada a cada celda libre
            alcanzables = 0
            for f in range(lab.filas):
                for c in range(lab.columnas):
                    if lab.matriz[f][c] == LIBRE and lab.distancia(lab.entrada, (f, c)) >= 0:
                        alcanzables += 1
            self.assertEqual(alcanzables, contar_libres(lab))

    def test_bordes_son_pared(self):
        lab = Laberinto(21, 31, semilla=3)
        for c in range(lab.columnas):
            self.assertFalse(lab.es_libre((0, c)))
            self.assertFalse(lab.es_libre((lab.filas - 1, c)))

    def test_bfs_es_el_mas_corto(self):
        """En un laberinto perfecto el camino es único; con atajos debe ser <=."""
        perfecto = Laberinto(21, 31, semilla=7)
        con_atajos = Laberinto(21, 31, semilla=7, atajos=0.3)
        d1 = perfecto.distancia(perfecto.entrada, perfecto.salida)
        d2 = con_atajos.distancia(con_atajos.entrada, con_atajos.salida)
        self.assertLessEqual(d2, d1)

    def test_camino_es_continuo(self):
        lab = Laberinto(15, 21, semilla=1)
        camino = lab.camino_mas_corto(lab.entrada, lab.salida)
        nodo = camino.cabeza
        while nodo.siguiente is not None:
            a, b = nodo.dato, nodo.siguiente.dato
            self.assertEqual(abs(a[0] - b[0]) + abs(a[1] - b[1]), 1)
            self.assertTrue(lab.es_libre(b))
            nodo = nodo.siguiente

    def test_sin_camino_a_pared(self):
        lab = Laberinto(15, 21, semilla=1)
        self.assertIsNone(lab.camino_mas_corto(lab.entrada, (0, 0)))


class TestEnemigos(unittest.TestCase):
    def test_patrullero_ida_y_vuelta(self):
        lab = Laberinto(15, 21, semilla=2)
        ruta = Patrullero.crear_ruta(lab, lab.entrada, lab.salida, max_pasos=6)
        # 6 de ida + 4 de vuelta (sin repetir extremos)
        self.assertEqual(ruta.tamano(), 10)
        e = Patrullero(ruta)
        posiciones = [e.posicion]
        for _ in range(ruta.tamano()):
            e.paso(lab, None)
            posiciones.append(e.posicion)
        self.assertEqual(posiciones[0], posiciones[-1])      # dio la vuelta completa
        for a, b in zip(posiciones, posiciones[1:]):
            self.assertEqual(abs(a[0] - b[0]) + abs(a[1] - b[1]), 1)

    def test_cazador_se_acerca(self):
        lab = Laberinto(15, 21, semilla=2)
        c = Cazador(lab.salida, lentitud=1)
        antes = lab.distancia(c.posicion, lab.entrada)
        c.paso(lab, lab.entrada)
        self.assertEqual(lab.distancia(c.posicion, lab.entrada), antes - 1)


class TestPartida(unittest.TestCase):
    def nueva_sin_enemigos(self, nivel="Fácil"):
        p = Partida(nivel, semilla=5)
        p.enemigos = ListaCircular()
        return p

    def recorrer_pista(self, p):
        camino = p.pista()
        anterior = None
        for celda in camino:
            if anterior is not None:
                p.mover(celda[0] - anterior[0], celda[1] - anterior[1])
            anterior = celda

    def test_ganar(self):
        p = self.nueva_sin_enemigos()
        self.recorrer_pista(p)
        self.assertEqual(p.estado, GANADO)
        self.assertGreater(p.puntaje(), 0)
        self.assertEqual(p.mover(0, 1), "fin")    # ya no se mueve

    def test_pared_no_cuenta(self):
        p = self.nueva_sin_enemigos()
        self.assertEqual(p.mover(-1, 0), "pared")   # arriba de la entrada hay pared
        self.assertEqual(p.mover(5, 5), "pared")    # dirección inválida
        self.assertEqual(p.movimientos, 0)

    def test_deshacer(self):
        p = self.nueva_sin_enemigos()
        self.assertFalse(p.deshacer())             # nada que deshacer
        inicio = p.jugador
        for df, dc in ((0, 1), (1, 0)):
            if p.mover(df, dc) == "movio":
                break
        self.assertTrue(p.deshacer())
        self.assertEqual(p.jugador, inicio)
        self.assertEqual(p.camino.tamano(), 1)

    def test_perder_por_tiempo(self):
        p = self.nueva_sin_enemigos()
        for _ in range(NIVELES["Fácil"]["tiempo"]):
            p.pasar_segundo()
        self.assertEqual(p.estado, PERDIDO)
        self.assertEqual(p.puntaje(), 0)

    def test_perder_por_enemigo(self):
        p = Partida("Medio", semilla=1)
        enemigo = next(iter(p.enemigos))
        p.jugador = enemigo.ruta.obtener(1)         # el siguiente paso de su ruta
        self.assertTrue(p.mover_enemigos())
        self.assertEqual(p.estado, PERDIDO)

    def test_enemigos_lejos_al_inicio(self):
        for nivel in NIVELES:
            for s in range(10):
                p = Partida(nivel, semilla=s)
                for e in p.enemigos:
                    self.assertGreater(p.laberinto.distancia(p.jugador, e.posicion), 4)

    def test_siempre_se_puede_ganar(self):
        """Existe un camino entrada -> salida que no pisa rutas de patrulla."""
        for nivel in NIVELES:
            for s in range(15):
                p = Partida(nivel, semilla=s)
                lab = p.laberinto
                ocupadas = [[False] * lab.columnas for _ in range(lab.filas)]
                for e in p.enemigos:
                    if e.tipo == "patrullero":
                        for celda in e.ruta:
                            ocupadas[celda[0]][celda[1]] = True
                self.assertIsNotNone(lab.camino_mas_corto(lab.entrada, lab.salida, ocupadas))

    def test_nivel_invalido(self):
        self.assertRaises(ValueError, Partida, "Imposible")


class TestRecords(unittest.TestCase):
    def setUp(self):
        self.ruta = os.path.join(tempfile.mkdtemp(), "records.txt")

    def test_guardar_y_cargar_misma_forma(self):
        g = GestorRecords(self.ruta)
        for nombre, pts in (("ana", 500), ("bo", 300), ("cy", 800), ("di", 400)):
            g.agregar(Record(nombre, pts, "Fácil", 30, 50))
        g2 = GestorRecords(self.ruta)
        self.assertEqual(g2.recorrido_texto("preorden"), g.recorrido_texto("preorden"))
        mayor = g2.ordenados().cola.dato
        self.assertEqual(mayor.nombre, "cy")

    def test_archivo_danado(self):
        with open(self.ruta, "w", encoding="utf-8") as f:
            f.write("ana;100;Fácil;10;20\nbasura\nluis;xx;Medio;1;2\n")
        g = GestorRecords(self.ruta)
        self.assertEqual(g.arbol.tamano(), 1)

    def test_validaciones(self):
        self.assertFalse(validar_nombre("   ")[0])
        self.assertFalse(validar_nombre("a;b")[0])
        self.assertFalse(validar_nombre("x" * 16)[0])
        self.assertEqual(validar_nombre("  Ana  "), (True, "Ana"))
        self.assertFalse(validar_entero("abc")[0])
        self.assertFalse(validar_entero("-3")[0])
        self.assertEqual(validar_entero(" 42 "), (True, 42))


if __name__ == "__main__":
    unittest.main()
